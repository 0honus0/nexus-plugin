import { z as e } from "zod";
import { Fragment as t, Transition as n, computed as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createTextVNode as c, createVNode as l, defineComponent as u, inject as d, mergeModels as f, mergeProps as p, nextTick as m, normalizeClass as h, onScopeDispose as g, openBlock as _, ref as v, renderList as y, renderSlot as b, resolveDynamicComponent as x, shallowRef as S, toDisplayString as C, unref as w, useId as T, useModel as E, useSlots as D, useTemplateRef as ee, vModelDynamic as O, vShow as k, watch as A, withCtx as j, withDirectives as M, withModifiers as N } from "vue";
import { animateMini as P } from "motion-v";
import { unrefElement as F, useEventListener as I, usePointerSwipe as te, usePreferredReducedMotion as L, useResizeObserver as ne, useStorage as R, useWindowSize as z } from "@vueuse/core";
import { CollapsibleContent as B, CollapsibleRoot as V, CollapsibleTrigger as re, ContextMenuContent as ie, ContextMenuItem as ae, ContextMenuPortal as H, ContextMenuRoot as oe, ContextMenuSeparator as se, ContextMenuTrigger as ce, DialogClose as le, DialogContent as ue, DialogDescription as de, DialogOverlay as fe, DialogPortal as pe, DialogRoot as me, DialogTitle as he, DropdownMenuContent as ge, DropdownMenuItem as _e, DropdownMenuPortal as ve, DropdownMenuRoot as ye, DropdownMenuSeparator as be, DropdownMenuTrigger as xe, Primitive as Se, SelectContent as Ce, SelectIcon as we, SelectItem as Te, SelectItemText as Ee, SelectPortal as De, SelectRoot as Oe, SelectScrollDownButton as ke, SelectScrollUpButton as Ae, SelectTrigger as je, SelectValue as Me, SelectViewport as Ne, SliderRange as Pe, SliderRoot as Fe, SliderThumb as Ie, SliderTrack as Le, SwitchRoot as Re, SwitchThumb as ze, TabsContent as Be, TabsList as Ve, TabsRoot as He, TabsTrigger as Ue, ToastClose as We, ToastDescription as Ge, ToastProvider as Ke, ToastRoot as qe, ToastViewport as Je, VisuallyHidden as Ye } from "reka-ui";
import { ChevronDown as U, ChevronUp as W, Circle as Xe, CircleAlert as Ze, CircleCheck as Qe, CircleX as $e, Folder as et, Info as tt, LoaderCircle as nt, PanelsTopLeft as rt, Puzzle as it, Terminal as at, X as ot } from "@lucide/vue";
import st from "interactjs";
// src/ui/browser/components/UiButton.vue?vue&type=script&setup=true&lang.ts
var ct = [
	"data-appearance",
	"data-tone",
	"data-density",
	"type",
	"disabled",
	"aria-busy",
	"data-loading-animation",
	"data-loading-placement"
], lt = { class: "ui-button__content" }, ut = {
	key: 0,
	class: "ui-button__leading"
}, dt = { class: "ui-button__leading-content" }, ft = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, pt = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, mt = /*@__PURE__*/ u({
	__name: "UiButton",
	props: {
		appearance: { default: "soft" },
		tone: { default: "neutral" },
		density: { default: "default" },
		type: { default: "button" },
		disabled: {
			type: Boolean,
			default: !1
		},
		loading: {
			type: Boolean,
			default: !1
		},
		loadingAnimation: { default: "icon" },
		block: {
			type: Boolean,
			default: !1
		},
		iconOnly: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		let t = e, n = D();
		function r() {
			return t.loadingAnimation === "icon" && (t.iconOnly || !!n.leading);
		}
		function i() {
			return !t.iconOnly && n.leading ? "leading" : "content";
		}
		return (e, n) => (_(), o("button", {
			"data-ui": "button",
			"data-appearance": t.appearance,
			"data-tone": t.tone,
			"data-density": t.density,
			type: t.type,
			disabled: t.disabled || t.loading,
			"aria-busy": t.loading || void 0,
			"data-loading-animation": t.loading ? r() ? "icon" : "spinner" : void 0,
			"data-loading-placement": t.loading && !r() ? i() : void 0,
			class: h(["ui-button", {
				"ui-button--block": t.block,
				"ui-button--icon-only": t.iconOnly
			}])
		}, [s("span", lt, [
			e.$slots.leading ? (_(), o("span", ut, [s("span", dt, [b(e.$slots, "leading", {}, void 0, !0)]), t.loading && !r() && i() === "leading" ? (_(), o("span", ft, [...n[0] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)])) : a("v-if", !0),
			b(e.$slots, "default", {}, void 0, !0),
			b(e.$slots, "trailing", {}, void 0, !0)
		]), t.loading && !r() && i() === "content" ? (_(), o("span", pt, [...n[1] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)], 10, ct));
	}
}), G = (e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
}, K = /*#__PURE__*/ G(mt, [["__scopeId", "data-v-bcddf2a3"]]), ht = {
	class: "ui-field",
	"data-ui": "field"
}, gt = ["for"], _t = ["id"], vt = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiField",
	props: {
		label: {},
		hint: {},
		id: {}
	},
	setup(e) {
		let t = e, n = T();
		return (r, i) => (_(), o("div", ht, [
			s("label", { for: t.id ?? w(n) }, C(e.label), 9, gt),
			b(r.$slots, "default", {
				id: t.id ?? w(n),
				describedby: e.hint ? `${t.id ?? w(n)}-hint` : void 0
			}, void 0, !0),
			e.hint ? (_(), o("p", {
				key: 0,
				id: `${t.id ?? w(n)}-hint`
			}, C(e.hint), 9, _t)) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-2f372308"]]), yt = [
	"data-density",
	"data-invalid",
	"data-disabled"
], bt = {
	key: 0,
	class: "ui-input__accessory"
}, xt = [
	"id",
	"type",
	"disabled"
], St = {
	key: 1,
	class: "ui-input__accessory"
}, Ct = /*#__PURE__*/ G(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiInput",
	props: /*@__PURE__*/ f({
		type: { default: "text" },
		disabled: { type: Boolean },
		density: { default: "default" },
		invalid: { type: Boolean }
	}, {
		modelValue: { default: "" },
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = E(e, "modelValue"), n = T();
		return (r, i) => (_(), o("div", {
			class: "ui-input",
			"data-ui": "input",
			"data-density": e.density,
			"data-invalid": e.invalid || void 0,
			"data-disabled": e.disabled || void 0
		}, [
			r.$slots.leading ? (_(), o("span", bt, [b(r.$slots, "leading", {}, void 0, !0)])) : a("v-if", !0),
			M(s("input", p({
				...r.$attrs,
				...e.invalid ? { "aria-invalid": !0 } : {}
			}, {
				id: typeof r.$attrs.id == "string" && r.$attrs.id ? r.$attrs.id : w(n),
				"onUpdate:modelValue": i[0] ||= (e) => t.value = e,
				type: e.type,
				disabled: e.disabled
			}), null, 16, xt), [[O, t.value]]),
			r.$slots.trailing ? (_(), o("span", St, [b(r.$slots, "trailing", {}, void 0, !0)])) : a("v-if", !0)
		], 8, yt));
	}
}), [["__scopeId", "data-v-619d8796"]]), wt = Symbol("ui.motion"), q = /* @__PURE__ */ new WeakMap();
function Tt(e) {
	return e.startsWith("--") ? e : e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
function J() {
	let e = L(), t = d(wt, {
		enabled: r(() => e.value !== "reduce"),
		speed: r(() => 1)
	}), n = /* @__PURE__ */ new Map();
	function i(e, r, i, a = () => {}) {
		let o = Object.keys(r.at(-1) ?? {}).filter((e) => ![
			"offset",
			"easing",
			"composite"
		].includes(e)), s = q.get(e), c = s ? getComputedStyle(e) : void 0, l = new Map(s?.properties.map((e) => [e, c.getPropertyValue(Tt(e))]));
		if (s?.finish(), !t.enabled.value || !e.animate) return a(), () => {};
		let u = new Map(o.map((t) => {
			let n = Tt(t);
			return [n, e.style.getPropertyValue(n)];
		})), d = Object.fromEntries(o.map((e) => [e, r.map((t, n) => n === 0 && l.has(e) ? l.get(e) : t[e])])), f = P(e, d, {
			duration: i / 1e3,
			ease: [
				.25,
				.1,
				.25,
				1
			]
		});
		f.speed = t.speed.value;
		let p = !1;
		function m() {
			if (!p) {
				p = !0, n.delete(f), q.get(e)?.finish === m && q.delete(e), f.cancel();
				for (let [t, n] of u) n ? e.style.setProperty(t, n) : e.style.removeProperty(t);
				a();
			}
		}
		return q.set(e, {
			finish: m,
			properties: o
		}), n.set(f, m), f.finished.then(m, m), m;
	}
	return A(t.enabled, (e) => {
		if (!e) for (let e of [...n.values()]) e();
	}, { flush: "sync" }), A(t.speed, (e) => {
		for (let t of n.keys()) t.speed = e;
	}, { flush: "sync" }), g(() => {
		for (let e of [...n.values()]) e();
	}), {
		play: i,
		enabled: t.enabled
	};
}
// src/ui/browser/ui-overlay.ts
var Y;
function Et() {
	Y?.dismiss();
}
function X(e) {
	let t = !0, n = { dismiss() {
		t = !1, e.value = !1;
	} };
	return A(e, (e) => {
		e ? (Y !== n && Y?.dismiss(), t = !0, Y = n) : Y === n && (Y = void 0);
	}, {
		immediate: !0,
		flush: "sync"
	}), g(() => {
		Y === n && (Y = void 0);
	}), {
		interactOutside() {
			t = !1;
		},
		closeAutoFocus(e) {
			t || e.preventDefault();
		},
		select(e, t) {
			n.dismiss(), e?.focus({ preventScroll: !0 }), t();
		}
	};
}
// src/ui/browser/components/UiSelect.vue?vue&type=script&setup=true&lang.ts
var Z = "inset(-48px)", Dt = /*#__PURE__*/ G(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSelect",
	props: /*@__PURE__*/ f({
		options: {},
		placeholder: {},
		name: {},
		required: {
			type: Boolean,
			default: !1
		},
		disabled: {
			type: Boolean,
			default: !1
		},
		invalid: {
			type: Boolean,
			default: !1
		},
		block: {
			type: Boolean,
			default: !1
		},
		density: { default: "default" },
		contentAlign: { default: "center" }
	}, {
		modelValue: {},
		modelModifiers: {},
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: ["update:modelValue", "update:open"],
	setup(e) {
		let s = E(e, "modelValue"), u = E(e, "open"), d = X(u), { play: f } = J(), m = e, h = r(() => m.options.find((e) => e.value === s.value)?.label ?? m.placeholder ?? ""), g = null;
		function v(e) {
			g = e.querySelector("[data-ui=\"select-content\"]"), g?.setAttribute("data-positioning", "");
		}
		function b() {
			if (!u.value || !g) return;
			let e = g;
			g = null, e.removeAttribute("data-positioning");
			let t = e.dataset.side === "top" ? "inset(18px -48px -48px)" : "inset(-48px -48px 18px)";
			f(e, [{
				opacity: 0,
				clipPath: t
			}, {
				opacity: 1,
				clipPath: Z
			}], 150);
		}
		function x(e, t) {
			let n = e.querySelector("[data-ui=\"select-content\"]");
			!n || n === g ? (g = null, t()) : (e.setAttribute("inert", ""), e.setAttribute("aria-hidden", "true"), f(n, [{
				opacity: 1,
				clipPath: Z
			}, {
				opacity: 0,
				clipPath: Z
			}], 90, t));
		}
		return (e, r) => (_(), i(w(Oe), {
			modelValue: s.value,
			"onUpdate:modelValue": r[0] ||= (e) => s.value = e,
			open: u.value,
			"onUpdate:open": r[1] ||= (e) => u.value = e,
			name: m.name,
			required: m.required,
			disabled: m.disabled || m.options.length === 0
		}, {
			default: j(() => [l(w(je), p(e.$attrs, {
				"data-ui": "select",
				"data-density": m.density,
				"aria-invalid": m.invalid || void 0,
				class: ["ui-select", { "ui-select--block": m.block }]
			}), {
				default: j(() => [l(w(Me), {
					class: "ui-select__value",
					placeholder: m.placeholder
				}, {
					default: j(() => [c(C(h.value), 1)]),
					_: 1
				}, 8, ["placeholder"]), l(w(we), { class: "ui-select__icon" }, {
					default: j(() => [l(w(U), { size: 15 })]),
					_: 1
				})]),
				_: 1
			}, 16, [
				"data-density",
				"aria-invalid",
				"class"
			]), m.options.length ? (_(), i(w(De), { key: 0 }, {
				default: j(() => [l(n, {
					appear: "",
					css: !1,
					onBeforeEnter: v,
					onLeave: x
				}, {
					default: j(() => [u.value ? (_(), i(w(Ce), {
						key: 0,
						"force-mount": "",
						"data-ui": "select-content",
						class: "ui-select-content",
						position: "popper",
						"body-lock": !1,
						"disable-outside-pointer-events": !1,
						onPlaced: b,
						onPointerDownOutside: w(d).interactOutside,
						onCloseAutoFocus: w(d).closeAutoFocus,
						align: m.contentAlign,
						"side-offset": 6,
						"collision-padding": 12
					}, {
						default: j(() => [
							l(w(Ae), { class: "ui-select-scroll" }, {
								default: j(() => [l(w(W), { size: 15 })]),
								_: 1
							}),
							l(w(Ne), { class: "ui-select-viewport" }, {
								default: j(() => [(_(!0), o(t, null, y(m.options, (e) => (_(), i(w(Te), {
									key: e.value,
									value: e.value,
									disabled: e.disabled,
									class: "ui-select-option"
								}, {
									default: j(() => [a(" 当前值由上方选择框展示；选中语义与键盘高亮由 Reka 保留。 "), l(w(Ee), { class: "ui-select-option__label" }, {
										default: j(() => [c(C(e.label), 1)]),
										_: 2
									}, 1024)]),
									_: 2
								}, 1032, ["value", "disabled"]))), 128))]),
								_: 1
							}),
							l(w(ke), { class: "ui-select-scroll" }, {
								default: j(() => [l(w(U), { size: 15 })]),
								_: 1
							})
						]),
						_: 1
					}, 8, [
						"onPointerDownOutside",
						"onCloseAutoFocus",
						"align"
					])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})) : a("v-if", !0)]),
			_: 1
		}, 8, [
			"modelValue",
			"open",
			"name",
			"required",
			"disabled"
		]));
	}
}), [["__scopeId", "data-v-a9789906"]]), Ot = ["data-tone", "data-expanded"], kt = { class: "ui-toast__icon" }, At = { class: "ui-toast__content" }, jt = {
	key: 0,
	class: "ui-toast__footer"
}, Mt = ["aria-expanded"], Nt = { class: "ui-toast__controls" }, Pt = {
	key: 0,
	class: "ui-toast__page"
}, Ft = { "aria-hidden": "true" }, It = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiToastStack",
	props: {
		items: {},
		label: {},
		closeLabel: {},
		expandLabel: {},
		collapseLabel: {},
		positionLabel: {},
		duration: { default: 5e3 }
	},
	emits: ["dismiss"],
	setup(e, { emit: t }) {
		let n = e, u = t, d = v(), f = v(!1), g = v(), y = v(), b = v(!1), S = {
			info: tt,
			success: Qe,
			warning: Ze,
			error: Ze
		}, T = r(() => n.items.findIndex((e) => e.id === d.value)), E = r(() => n.items[T.value]), D = r(() => n.items.length - T.value), { play: ee } = J(), O = !1, k, M = () => {}, P = !1, F = 0, L = 0, R = 0;
		function z() {
			!f.value && y.value && (b.value = y.value.scrollHeight > y.value.clientHeight + 1);
		}
		ne(y, z), A([() => E.value?.message, f], () => m(z)), A(() => n.items.map((e) => e.id), (e, t = []) => {
			let n = e.at(-1);
			if (n !== void 0 && !t.includes(n)) d.value = n;
			else if (!e.includes(d.value)) {
				let n = t.indexOf(d.value);
				d.value = e[Math.max(0, Math.min(n - 1, e.length - 1))];
			}
		}, {
			immediate: !0,
			flush: "sync"
		}), A(d, async (e) => {
			M(), O = !1, f.value = !1, b.value = !1, await m(), z(), g.value && d.value === e && (M = ee(g.value, [{
				opacity: 0,
				transform: "translateY(-6px)"
			}, {
				opacity: 1,
				transform: "translateY(0)"
			}], 160));
		});
		function B(e) {
			if (n.items.length < 2) return;
			let t = (T.value + e + n.items.length) % n.items.length, r = g.value?.contains(document.activeElement);
			d.value = n.items[t].id, r && m(() => g.value?.focus({ preventScroll: !0 }));
		}
		function V() {
			if (!E.value) return;
			let e = g.value?.contains(document.activeElement);
			u("dismiss", E.value.id), e && n.items.length && m(() => g.value?.focus({ preventScroll: !0 }));
		}
		function re(e) {
			f.value = !f.value, e.currentTarget.focus({ preventScroll: !0 });
		}
		I("keydown", (e) => {
			e.key === "Escape" && E.value && (e.preventDefault(), e.stopPropagation(), V());
		}, { capture: !0 });
		function ie(e) {
			(e.key === "ArrowUp" || e.key === "ArrowDown") && (e.preventDefault(), e.stopPropagation(), B(e.key === "ArrowUp" ? 1 : -1));
		}
		function ae(e) {
			if (e.ctrlKey || (e.stopPropagation(), f.value && e.target.closest(".ui-toast__message")) || (e.preventDefault(), n.items.length < 2)) return;
			let t = performance.now();
			if (t < R || !Number.isFinite(e.deltaY)) return;
			(t - L > 200 || Math.sign(F) !== Math.sign(e.deltaY)) && (F = 0), L = t;
			let r = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 200 : 1);
			F += r, Math.abs(F) < 32 || (B(F > 0 ? -1 : 1), F = 0, R = t + 260);
		}
		let H = te(g, {
			threshold: 24,
			onSwipeStart(e) {
				M(), k = d.value, O = e.isPrimary && e.button === 0 && !e.target.closest("button, .ui-toast__message.is-expanded"), P = !1;
			},
			onSwipe() {
				if (!O || k !== d.value || !g.value) return;
				P = !0;
				let e = -H.distanceX.value;
				Math.abs(e) > Math.abs(H.distanceY.value) && (g.value.style.transform = `translateX(${e}px)`, g.value.style.opacity = String(Math.max(.3, 1 - Math.abs(e) / g.value.clientWidth)));
			},
			onSwipeEnd(e, t) {
				O && k === d.value && (O = !1, g.value && (g.value.style.removeProperty("transform"), g.value.style.removeProperty("opacity")), e.type !== "pointercancel" && (t === "left" || t === "right" ? Math.abs(H.distanceX.value) >= 56 && V() : (t === "up" || t === "down") && B(t === "up" ? -1 : 1)));
			}
		});
		return I(g, "click", (e) => {
			P && (e.preventDefault(), e.stopImmediatePropagation());
		}, { capture: !0 }), I(g, "pointercancel", () => {
			O = !1;
		}), (t, n) => (_(), i(w(Ke), {
			duration: f.value ? Infinity : e.duration,
			label: e.label,
			"disable-swipe": ""
		}, {
			default: j(() => [E.value ? (_(), i(w(qe), {
				key: E.value.id,
				"as-child": "",
				open: !0,
				"onUpdate:open": n[0] ||= (e) => {
					e || V();
				}
			}, {
				default: j(() => [s("li", {
					ref_key: "card",
					ref: g,
					class: "ui-toast",
					"data-ui": "toast",
					"data-tone": E.value.tone,
					"data-expanded": f.value || void 0,
					onKeydown: ie
				}, [
					s("div", kt, [(_(), i(x(S[E.value.tone]), {
						size: 18,
						"aria-hidden": "true"
					}))]),
					s("div", At, [l(w(Ge), { "as-child": "" }, {
						default: j(() => [s("p", {
							ref_key: "message",
							ref: y,
							class: h(["ui-toast__message", { "is-expanded": f.value }])
						}, C(E.value.message), 3)]),
						_: 1
					}), b.value || f.value ? (_(), o("div", jt, [s("button", {
						class: "ui-toast__expand",
						type: "button",
						"aria-expanded": f.value,
						onClick: re
					}, [c(C(f.value ? e.collapseLabel : e.expandLabel) + " ", 1), f.value ? (_(), i(w(W), {
						key: 0,
						size: 12,
						"aria-hidden": "true"
					})) : (_(), i(w(U), {
						key: 1,
						size: 12,
						"aria-hidden": "true"
					}))], 8, Mt)])) : a("v-if", !0)]),
					s("div", Nt, [l(w(We), {
						class: "ui-toast__close",
						"aria-label": e.closeLabel
					}, {
						default: j(() => [l(w(ot), {
							size: 15,
							"aria-hidden": "true"
						})]),
						_: 1
					}, 8, ["aria-label"]), e.items.length > 1 ? (_(), o("span", Pt, [l(w(Ye), null, {
						default: j(() => [c(C(e.positionLabel(D.value, e.items.length)), 1)]),
						_: 1
					}), s("span", Ft, C(D.value) + "/" + C(e.items.length), 1)])) : a("v-if", !0)])
				], 40, Ot)]),
				_: 1
			})) : a("v-if", !0), l(w(Je), p(t.$attrs, {
				class: "ui-toast-stack",
				"data-ui": "toast-stack",
				"data-count": Math.min(e.items.length, 3),
				label: e.label,
				onWheel: ae,
				onTouchmove: n[1] ||= N(() => {}, ["stop"]),
				onPointerdown: n[2] ||= N(() => {}, ["stop"]),
				onPointerup: n[3] ||= N(() => {}, ["stop"])
			}), null, 16, ["data-count", "label"])]),
			_: 1
		}, 8, ["duration", "label"]));
	}
}), Q = /* @__PURE__ */ u({
	__name: "UiTransition",
	props: {
		preset: { default: "panel" },
		appear: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let t = e, { play: r } = J(), a = /* @__PURE__ */ new WeakMap();
		function o(e = !1) {
			if (t.preset === "drop") {
				let t = {
					opacity: 1,
					clipPath: "inset(-16px)"
				};
				return e ? [t, {
					opacity: 0,
					clipPath: "inset(100% -16px -16px)"
				}] : [{
					opacity: 0,
					clipPath: "inset(-16px -16px 100%)"
				}, t];
			}
			let n = t.preset === "panel" ? [{
				opacity: 0,
				scale: ".98"
			}, {
				opacity: 1,
				scale: "1"
			}] : [{ opacity: 0 }, { opacity: 1 }];
			return e ? n.reverse() : n;
		}
		function s(e, n) {
			let i = e;
			if (i.inert = !1, a.has(i)) {
				let e = a.get(i);
				e === null ? i.removeAttribute("aria-hidden") : i.setAttribute("aria-hidden", e), a.delete(i);
			}
			t.preset === "none" ? n() : r(i, o(), t.preset === "context-menu" ? 90 : 200, n);
		}
		function c(e, n) {
			let i = e;
			i.inert = !0, a.has(i) || a.set(i, i.getAttribute("aria-hidden")), i.setAttribute("aria-hidden", "true"), t.preset === "none" ? n() : r(i, o(!0), t.preset === "context-menu" ? 60 : 140, n);
		}
		return (t, r) => (_(), i(n, {
			css: !1,
			appear: e.appear,
			onEnter: s,
			onLeave: c
		}, {
			default: j(() => [b(t.$slots, "default")]),
			_: 3
		}, 8, ["appear"]));
	}
}), Lt = e.enum([
	"compact",
	"medium",
	"wide"
]), Rt = {
	compact: {
		minWidth: 0,
		columns: 4
	},
	medium: {
		minWidth: 700,
		columns: 8
	},
	wide: {
		minWidth: 1200,
		columns: 12
	}
};
function zt(e) {
	return e >= Rt.wide.minWidth ? "wide" : e >= Rt.medium.minWidth ? "medium" : "compact";
}
// src/ui/browser/ui-resize.ts
var Bt = {
	top: "[data-ui-resize-edges~=\"top\"]",
	right: "[data-ui-resize-edges~=\"right\"]",
	bottom: "[data-ui-resize-edges~=\"bottom\"]",
	left: "[data-ui-resize-edges~=\"left\"]"
}, Vt = e.object({
	x: e.number().finite(),
	y: e.number().finite(),
	width: e.number().positive().finite(),
	height: e.number().positive().finite()
}), Ht = e.partialRecord(Lt, Vt);
function Ut(e, t, n, i) {
	let { width: a, height: o } = z({ includeScrollbar: !1 }), s = r(() => zt(a.value)), c = r(() => e.size !== "fullscreen" && !!(e.draggable || e.resizable)), l = S(), u = R(() => `nexus.ui.dialog.${e.persistenceKey ?? ""}`, {}, void 0, {
		deep: !1,
		writeDefaults: !1,
		serializer: {
			read: (e) => Ht.parse(JSON.parse(e)),
			write: JSON.stringify
		},
		onError: i
	});
	function d(e) {
		let t = Math.max(1, a.value - 32), n = Math.max(1, o.value - 32), r = Math.min(t, Math.max(Math.min(320, t), e.width)), i = Math.min(n, Math.max(Math.min(240, n), e.height));
		return {
			x: Math.max(16, Math.min(e.x, a.value - r - 16)),
			y: Math.max(16, Math.min(e.y, o.value - i - 16)),
			width: r,
			height: i
		};
	}
	function f() {
		e.persistenceKey && l.value && (u.value = {
			...u.value,
			[s.value]: { ...l.value }
		});
	}
	function p() {
		if (l.value) return d(l.value);
		let e = n.value?.getBoundingClientRect();
		if (e) return d({
			x: e.left,
			y: e.top,
			width: e.width,
			height: e.height
		});
	}
	function m(e, t, n = 0, r = 0) {
		let i = p();
		if (!i) return;
		let s = i.x + n, c = i.y + r;
		l.value = d({
			...i,
			x: s,
			y: c,
			width: Math.min(e, a.value - s - 16),
			height: Math.min(t, o.value - c - 16)
		});
	}
	function h(t, n) {
		if (!c.value || !e.resizable) return;
		let r = p();
		r && (m(r.width + t, r.height + n), f());
	}
	A([
		n,
		t,
		c,
		() => e.persistenceKey,
		() => e.size,
		() => e.draggable,
		() => e.resizable,
		s
	], ([t, n, r], i, a) => {
		let o;
		a(() => {
			o?.unset();
		}), l.value = void 0, t && n && r && (l.value = e.persistenceKey && u.value[s.value] || void 0, o = st(t).draggable({
			enabled: !!e.draggable,
			allowFrom: ".ui-dialog__header",
			ignoreFrom: "button, a, input, textarea, select, [contenteditable], [data-dialog-no-drag]",
			listeners: {
				move: (e) => {
					let t = p();
					t && (l.value = d({
						...t,
						x: t.x + e.dx,
						y: t.y + e.dy
					}));
				},
				end: f
			}
		}).resizable({
			enabled: !!e.resizable,
			edges: Bt,
			modifiers: [st.modifiers.restrictSize({ min: {
				width: 320,
				height: 240
			} })],
			listeners: {
				move: (e) => m(e.rect.width, e.rect.height, e.deltaRect.left, e.deltaRect.top),
				end: f
			}
		}));
	}, {
		immediate: !0,
		flush: "post"
	});
	let g = r(() => l.value && d(l.value));
	return {
		enabled: c,
		style: r(() => g.value ? {
			left: `${g.value.x}px`,
			top: `${g.value.y}px`,
			width: `${g.value.width}px`,
			height: `${g.value.height}px`,
			maxHeight: `${Math.max(1, o.value - 32)}px`,
			transform: "none"
		} : void 0),
		resizeBy: h
	};
}
// src/ui/browser/components/UiScrollArea.vue
var $ = /* @__PURE__ */ u({
	__name: "UiScrollArea",
	props: {
		asChild: {
			type: Boolean,
			default: !1
		},
		gutter: { default: "auto" },
		overflow: { default: "auto" },
		scrollbar: { default: "auto" }
	},
	setup(e) {
		let t = e;
		return (e, n) => (_(), i(w(Se), {
			"as-child": t.asChild,
			class: "ui-scroll-area",
			"data-scrollbar-gutter": t.gutter,
			"data-scroll-overflow": t.overflow,
			"data-scrollbar": t.scrollbar
		}, {
			default: j(() => [b(e.$slots, "default")]),
			_: 3
		}, 8, [
			"as-child",
			"data-scrollbar-gutter",
			"data-scroll-overflow",
			"data-scrollbar"
		]));
	}
}), Wt = ["aria-label"], Gt = {
	key: 0,
	class: "ui-resize-edges",
	"aria-hidden": "true"
}, Kt = ["data-ui-resize-edges"], qt = /*#__PURE__*/ G(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiResizeHandle",
	props: {
		label: {},
		edges: { type: Boolean }
	},
	emits: ["resize"],
	setup(e, { emit: n }) {
		let r = e, i = n;
		function c(e) {
			let t = {
				ArrowLeft: [-1, 0],
				ArrowRight: [1, 0],
				ArrowUp: [0, -1],
				ArrowDown: [0, 1]
			}[e.key];
			if (!t) return;
			e.preventDefault(), e.stopPropagation();
			let n = e.shiftKey ? 48 : 16;
			i("resize", t[0] * n, t[1] * n);
		}
		return (e, n) => (_(), o(t, null, [s("button", p(e.$attrs, {
			type: "button",
			"data-ui": "resize-handle",
			"data-ui-resize-edges": "bottom right",
			class: ["ui-resize-handle", { "has-edges": r.edges }],
			"aria-label": r.label,
			onKeydown: c
		}), null, 16, Wt), r.edges ? (_(), o("span", Gt, [(_(), o(t, null, y([
			"top",
			"right",
			"bottom",
			"left",
			"top left",
			"top right",
			"bottom left"
		], (e) => s("span", {
			key: e,
			"data-ui-resize-edges": e
		}, null, 8, Kt)), 64))])) : a("v-if", !0)], 64));
	}
}), [["__scopeId", "data-v-e6ff7434"]]), Jt = [
	"data-size",
	"data-geometry",
	"data-draggable"
], Yt = { class: "ui-dialog__surface" }, Xt = ["data-ui-selection"], Zt = { class: "ui-dialog__heading" }, Qt = { class: "ui-dialog__footer" }, $t = /*#__PURE__*/ G(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiDialog",
	props: /*@__PURE__*/ f({
		modal: {
			type: Boolean,
			default: !0
		},
		title: {},
		description: {},
		closeLabel: {},
		size: { default: "md" },
		showClose: {
			type: Boolean,
			default: !0
		},
		closeDisabled: {
			type: Boolean,
			default: !1
		},
		closeOnEscape: {
			type: Boolean,
			default: !0
		},
		closeOnInteractOutside: {
			type: Boolean,
			default: !0
		},
		draggable: { type: Boolean },
		resizable: {
			type: Boolean,
			default: !0
		},
		resizeLabel: {},
		persistenceKey: {},
		gutter: { default: "symmetric" },
		scrollbar: {}
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["storageError"], ["update:open"]),
	setup(e, { emit: t }) {
		let n = E(e, "open");
		A(n, (e) => {
			e && Et();
		}, {
			immediate: !0,
			flush: "sync"
		});
		let r = e, o = t, u = S(), d = Ut(r, n, u, (e) => o("storageError", e));
		function f() {
			m(!1);
		}
		function m(e) {
			(e || !r.closeDisabled) && (n.value = e);
		}
		return (e, t) => (_(), i(w(me), {
			open: n.value,
			modal: r.modal,
			"onUpdate:open": m
		}, {
			default: j(() => [l(w(pe), null, {
				default: j(() => [l(Q, { preset: "fade" }, {
					default: j(() => [r.modal && n.value ? (_(), i(w(fe), {
						key: 0,
						"force-mount": "",
						"data-ui": "dialog-overlay",
						class: "ui-dialog-overlay"
					})) : a("v-if", !0)]),
					_: 1
				}), l(Q, null, {
					default: j(() => [n.value ? (_(), i(w(ue), {
						key: 0,
						"force-mount": "",
						"as-child": "",
						onEscapeKeyDown: t[0] ||= (e) => (r.closeDisabled || !r.closeOnEscape) && e.preventDefault(),
						onInteractOutside: t[1] ||= (e) => (r.closeDisabled || !r.closeOnInteractOutside) && e.preventDefault()
					}, {
						default: j(() => [s("div", p({
							ref_key: "element",
							ref: u
						}, {
							...e.$attrs,
							...r.description ? {} : { "aria-describedby": void 0 }
						}, {
							"data-ui": "dialog",
							"data-size": r.size,
							"data-geometry": w(d).enabled.value || void 0,
							"data-draggable": w(d).enabled.value && r.draggable || void 0,
							style: w(d).style.value,
							class: "ui-dialog"
						}), [s("div", Yt, [
							l($, {
								"as-child": "",
								gutter: r.gutter,
								overflow: "hidden"
							}, {
								default: j(() => [s("header", {
									class: "ui-dialog__header",
									"data-ui-selection": r.draggable ? "none" : void 0
								}, [s("div", Zt, [l(w(he), { class: "ui-dialog__title" }, {
									default: j(() => [b(e.$slots, "title", { title: r.title }, () => [c(C(r.title), 1)], !0)]),
									_: 3
								}), r.description ? (_(), i(w(de), {
									key: 0,
									class: "ui-dialog__description"
								}, {
									default: j(() => [c(C(r.description), 1)]),
									_: 1
								})) : a("v-if", !0)]), r.showClose ? (_(), i(w(le), {
									key: 0,
									"as-child": ""
								}, {
									default: j(() => [l(K, {
										appearance: "ghost",
										"icon-only": "",
										disabled: r.closeDisabled,
										"aria-label": r.closeLabel
									}, {
										default: j(() => [l(w(ot), { size: 18 })]),
										_: 1
									}, 8, ["disabled", "aria-label"])]),
									_: 1
								})) : a("v-if", !0)], 8, Xt)]),
								_: 3
							}, 8, ["gutter"]),
							b(e.$slots, "body", { close: f }, () => [e.$slots.default ? (_(), i($, {
								key: 0,
								gutter: r.gutter,
								scrollbar: r.scrollbar,
								class: "ui-dialog__body"
							}, {
								default: j(() => [b(e.$slots, "default", { close: f }, void 0, !0)]),
								_: 3
							}, 8, ["gutter", "scrollbar"])) : a("v-if", !0)], !0),
							e.$slots.footer ? (_(), i($, {
								key: 0,
								"as-child": "",
								gutter: r.gutter,
								overflow: "hidden"
							}, {
								default: j(() => [s("footer", Qt, [b(e.$slots, "footer", { close: f }, void 0, !0)])]),
								_: 3
							}, 8, ["gutter"])) : a("v-if", !0)
						]), w(d).enabled.value && r.resizable ? (_(), i(qt, {
							key: 0,
							edges: "",
							label: r.resizeLabel ?? r.title,
							onResize: w(d).resizeBy
						}, null, 8, ["label", "onResize"])) : a("v-if", !0)], 16, Jt)]),
						_: 3
					})) : a("v-if", !0)]),
					_: 3
				})]),
				_: 3
			})]),
			_: 3
		}, 8, ["open", "modal"]));
	}
}), [["__scopeId", "data-v-2756f69c"]]);
// src/ui/browser/ui-selection.ts
function en(e) {
	let t = e.ownerDocument.getSelection();
	return !!t && !t.isCollapsed && t.rangeCount > 0 && t.toString().length > 0 && t.getRangeAt(0).intersectsNode(e);
}
function tn(e) {
	if (e.button !== 0 || !e.isPrimary || e.shiftKey) return;
	let t = e.currentTarget;
	en(t) && t.ownerDocument.getSelection()?.removeAllRanges();
}
function nn(e) {
	e.detail !== 0 && en(e.currentTarget) && (e.preventDefault(), e.stopImmediatePropagation());
}
var rn = {
	beforeMount(e) {
		e.addEventListener("pointerdown", tn, !0), e.addEventListener("click", nn, !0);
	},
	beforeUnmount(e) {
		e.removeEventListener("pointerdown", tn, !0), e.removeEventListener("click", nn, !0);
	}
}, an = [
	"disabled",
	"aria-label",
	"aria-describedby"
], on = ["id"], sn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiActionCard",
	props: {
		label: {},
		disabled: { type: Boolean }
	},
	setup(e) {
		let t = T();
		return (n, r) => (_(), o("button", {
			type: "button",
			class: "ui-action-card",
			disabled: e.disabled,
			"aria-label": e.label,
			"aria-describedby": w(t)
		}, [s("span", {
			id: w(t),
			class: "ui-action-card__content"
		}, [b(n.$slots, "default", {}, void 0, !0)], 8, on)], 8, an));
	}
}), [["__scopeId", "data-v-5969b36d"]]), cn = /* @__PURE__ */ u({
	__name: "UiContextMenu",
	props: /*@__PURE__*/ f({
		items: {},
		disabled: { type: Boolean }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let r = E(e, "open"), c = n, u = v(), d = X(r), f = (e) => d.select(F(u), () => c("select", e));
		return (n, c) => (_(), o(t, null, [a(" 右键、键盘菜单键、触屏长按与焦点收尾均交给 Reka；组件只处理样式和选项。 "), l(w(oe), {
			open: r.value,
			"onUpdate:open": c[1] ||= (e) => r.value = e,
			modal: !1
		}, {
			default: j(() => [l(w(ce), {
				ref_key: "trigger",
				ref: u,
				"as-child": "",
				disabled: e.disabled
			}, {
				default: j(() => [b(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(w(H), null, {
				default: j(() => [l(Q, { preset: "context-menu" }, {
					default: j(() => [r.value ? (_(), i(w(ie), {
						key: 0,
						"force-mount": "",
						"data-ui": "context-menu",
						class: "ui-menu",
						onInteractOutside: w(d).interactOutside,
						onPointerupCapture: c[0] ||= (e) => e.button !== 0 && e.preventDefault(),
						onCloseAutoFocus: w(d).closeAutoFocus,
						"side-offset": 8,
						"collision-padding": 12
					}, {
						default: j(() => [(_(!0), o(t, null, y(e.items, (e) => (_(), o(t, { key: e.id }, [e.separatorBefore ? (_(), i(w(se), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(w(ae), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => f(e.id)
						}, {
							default: j(() => [e.icon ? (_(), i(x(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, C(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, ["onInteractOutside", "onCloseAutoFocus"])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"])], 2112));
	}
}), ln = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiSwitch",
	props: /*@__PURE__*/ f({
		disabled: { type: Boolean },
		name: {},
		required: { type: Boolean }
	}, {
		modelValue: {
			type: Boolean,
			default: !1
		},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = E(e, "modelValue");
		return (n, r) => (_(), i(w(Re), {
			modelValue: t.value,
			"onUpdate:modelValue": r[0] ||= (e) => t.value = e,
			class: "ui-switch",
			"data-ui": "switch",
			disabled: e.disabled,
			name: e.name,
			required: e.required
		}, {
			default: j(() => [l(w(ze), { class: "ui-switch__thumb" })]),
			_: 1
		}, 8, [
			"modelValue",
			"disabled",
			"name",
			"required"
		]));
	}
}), [["__scopeId", "data-v-91553e58"]]), un = /*#__PURE__*/ G(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSlider",
	props: {
		modelValue: {},
		min: { default: 0 },
		max: { default: 100 },
		step: { default: 1 },
		disabled: { type: Boolean },
		name: {}
	},
	emits: [
		"update:modelValue",
		"commit",
		"cancel"
	],
	setup(e, { emit: t }) {
		let n = t;
		return (t, r) => (_(), i(w(Fe), {
			class: "ui-slider",
			"data-ui": "slider",
			"model-value": [e.modelValue],
			min: e.min,
			max: e.max,
			step: e.step,
			disabled: e.disabled,
			name: e.name,
			"onUpdate:modelValue": r[0] ||= (e) => e?.[0] !== void 0 && n("update:modelValue", e[0]),
			onValueCommit: r[1] ||= (e) => e[0] !== void 0 && n("commit", e[0]),
			onPointercancel: r[2] ||= (e) => n("cancel")
		}, {
			default: j(() => [l(w(Le), { class: "ui-slider__track" }, {
				default: j(() => [l(w(Pe), { class: "ui-slider__range" })]),
				_: 1
			}), l(w(Ie), p(t.$attrs, { class: "ui-slider__thumb" }), null, 16)]),
			_: 1
		}, 8, [
			"model-value",
			"min",
			"max",
			"step",
			"disabled",
			"name"
		]));
	}
}), [["__scopeId", "data-v-589610c4"]]), dn = ["data-stable"], fn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiTabs",
	props: /*@__PURE__*/ f({
		options: {},
		label: {},
		defaultValue: {},
		stableHeight: { type: Boolean }
	}, {
		modelValue: {},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let n = E(e, "modelValue");
		return (r, u) => (_(), i(w(He), {
			modelValue: n.value,
			"onUpdate:modelValue": u[0] ||= (e) => n.value = e,
			"default-value": e.defaultValue,
			class: "ui-tabs",
			"data-ui": "tabs"
		}, {
			default: j(() => [l(w(Ve), {
				class: "ui-tabs__list",
				"aria-label": e.label
			}, {
				default: j(() => [(_(!0), o(t, null, y(e.options, (e) => (_(), i(w(Ue), {
					key: e.value,
					value: e.value,
					disabled: e.disabled,
					class: "ui-tabs__trigger"
				}, {
					default: j(() => [e.icon ? (_(), i(x(e.icon), {
						key: 0,
						size: 16
					})) : a("v-if", !0), c(C(e.label), 1)]),
					_: 2
				}, 1032, ["value", "disabled"]))), 128))]),
				_: 1
			}, 8, ["aria-label"]), s("div", {
				class: "ui-tabs__panels",
				"data-stable": e.stableHeight || void 0
			}, [(_(!0), o(t, null, y(e.options, (t) => (_(), i(w(Be), {
				key: t.value,
				value: t.value,
				"force-mount": e.stableHeight,
				class: "ui-tabs__panel"
			}, {
				default: j(() => [b(r.$slots, t.value, {}, void 0, !0)]),
				_: 2
			}, 1032, ["value", "force-mount"]))), 128))], 8, dn)]),
			_: 3
		}, 8, ["modelValue", "default-value"]));
	}
}), [["__scopeId", "data-v-377c1fa0"]]), pn = ["data-tone"], mn = {
	key: 0,
	class: "ui-badge__dot",
	"aria-hidden": "true"
}, hn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiBadge",
	props: {
		tone: { default: "neutral" },
		dot: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		return (t, n) => (_(), o("span", {
			class: "ui-badge",
			"data-ui": "badge",
			"data-tone": e.tone
		}, [e.dot ? (_(), o("span", mn)) : a("v-if", !0), b(t.$slots, "default", {}, void 0, !0)], 8, pn));
	}
}), [["__scopeId", "data-v-94a33925"]]), gn = {
	class: "ui-empty-state",
	"data-ui": "empty-state"
}, _n = {
	key: 0,
	class: "ui-empty-state__icon",
	"aria-hidden": "true"
}, vn = { key: 1 }, yn = {
	key: 2,
	class: "ui-empty-state__actions"
}, bn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiEmptyState",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (_(), o("div", gn, [
			e.icon || t.$slots.icon ? (_(), o("span", _n, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 26 }))], !0)])) : a("v-if", !0),
			s("h3", null, C(e.title), 1),
			e.description ? (_(), o("p", vn, C(e.description), 1)) : a("v-if", !0),
			t.$slots.default ? (_(), o("div", yn, [b(t.$slots, "default", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-f7ed903a"]]), xn = ["data-tone"], Sn = ["disabled", "aria-label"], Cn = {
	key: 0,
	class: "ui-card__icon"
}, wn = {
	class: "ui-card__body",
	"data-ui-selection": "text"
}, Tn = {
	key: 0,
	class: "ui-card__title-line"
}, En = ["title"], Dn = { class: "ui-card__title-end" }, On = ["title"], kn = ["title"], An = {
	key: 3,
	class: "ui-card__tags"
}, jn = {
	key: 0,
	class: "ui-card__side"
}, Mn = {
	key: 0,
	class: "ui-card__badge"
}, Nn = {
	key: 1,
	class: "ui-card__actions"
}, Pn = {
	key: 1,
	class: "ui-card__footer"
}, Fn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiCard",
	props: {
		title: {},
		actionLabel: {},
		description: {},
		icon: {},
		tone: { default: "primary" },
		disabled: { type: Boolean }
	},
	emits: ["select"],
	setup(e) {
		return (t, n) => (_(), o("article", {
			class: "ui-card",
			"data-ui": "card",
			"data-tone": e.tone
		}, [
			M((_(), o("button", {
				type: "button",
				class: "ui-card__main",
				disabled: e.disabled,
				"aria-label": e.actionLabel,
				onClick: n[0] ||= (e) => t.$emit("select")
			}, [e.icon || t.$slots.icon ? (_(), o("span", Cn, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 23 }))], !0)])) : a("v-if", !0), s("span", wn, [
				t.$slots["title-end"] ? (_(), o("span", Tn, [s("strong", { title: e.title }, C(e.title), 9, En), s("span", Dn, [b(t.$slots, "title-end", {}, void 0, !0)])])) : (_(), o("strong", {
					key: 1,
					title: e.title
				}, C(e.title), 9, On)),
				e.description ? (_(), o("span", {
					key: 2,
					class: "ui-card__description",
					title: e.description
				}, C(e.description), 9, kn)) : a("v-if", !0),
				t.$slots.tags ? (_(), o("span", An, [b(t.$slots, "tags", {}, void 0, !0)])) : a("v-if", !0)
			])], 8, Sn)), [[w(rn)]]),
			t.$slots.aside || t.$slots.badge || t.$slots.actions ? (_(), o("div", jn, [b(t.$slots, "aside", {}, () => [t.$slots.badge ? (_(), o("div", Mn, [b(t.$slots, "badge", {}, void 0, !0)])) : a("v-if", !0), t.$slots.actions ? (_(), o("div", Nn, [b(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)], !0)])) : a("v-if", !0),
			t.$slots.footer ? (_(), o("div", Pn, [b(t.$slots, "footer", {}, void 0, !0)])) : a("v-if", !0)
		], 8, xn));
	}
}), [["__scopeId", "data-v-4238ec73"]]), In = /* @__PURE__ */ u({
	__name: "UiDropdownMenu",
	props: /*@__PURE__*/ f({
		items: {},
		disabled: { type: Boolean },
		align: { default: "end" },
		transition: { default: "none" }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ f(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let r = n, c = E(e, "open"), u = v(), d = X(c), f = (e) => d.select(F(u), () => r("select", e));
		return (n, r) => (_(), i(w(ye), {
			open: c.value,
			"onUpdate:open": r[0] ||= (e) => c.value = e,
			modal: !1
		}, {
			default: j(() => [l(w(xe), {
				ref_key: "trigger",
				ref: u,
				"as-child": "",
				disabled: e.disabled || !e.items.length
			}, {
				default: j(() => [b(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(w(ve), null, {
				default: j(() => [l(Q, { preset: e.transition === "fade" ? "fade" : "none" }, {
					default: j(() => [c.value ? (_(), i(w(ge), {
						key: 0,
						"force-mount": "",
						"data-ui": "dropdown-menu",
						class: "ui-menu",
						align: e.align,
						"side-offset": 5,
						"collision-padding": 12,
						onInteractOutside: w(d).interactOutside,
						onCloseAutoFocus: w(d).closeAutoFocus
					}, {
						default: j(() => [(_(!0), o(t, null, y(e.items, (e) => (_(), o(t, { key: e.id }, [e.separatorBefore ? (_(), i(w(be), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(w(_e), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => f(e.id)
						}, {
							default: j(() => [e.icon ? (_(), i(x(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, C(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, [
						"align",
						"onInteractOutside",
						"onCloseAutoFocus"
					])) : a("v-if", !0)]),
					_: 1
				}, 8, ["preset"])]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"]));
	}
}), Ln = {}, Rn = {
	class: "ui-list",
	"data-ui": "list"
};
function zn(e, t) {
	return _(), o("ul", Rn, [b(e.$slots, "default", {}, void 0, !0)]);
}
var Bn = /*#__PURE__*/ G(Ln, [["render", zn], ["__scopeId", "data-v-a19901d7"]]), Vn = {
	class: "ui-list-item",
	"data-ui": "list-item"
}, Hn = {
	key: 0,
	class: "ui-list-item__icon"
}, Un = {
	class: "ui-list-item__body",
	"data-ui-selection": "text"
}, Wn = { class: "ui-list-item__heading" }, Gn = ["title"], Kn = ["title"], qn = {
	key: 1,
	class: "ui-list-item__actions"
}, Jn = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiListItem",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (_(), o("li", Vn, [
			e.icon || t.$slots.icon ? (_(), o("span", Hn, [b(t.$slots, "icon", {}, () => [(_(), i(x(e.icon), { size: 20 }))], !0)])) : a("v-if", !0),
			s("div", Un, [s("div", Wn, [s("strong", { title: e.title }, C(e.title), 9, Gn), b(t.$slots, "badge", {}, void 0, !0)]), e.description || t.$slots.description ? (_(), o("div", {
				key: 0,
				class: "ui-list-item__description",
				title: e.description
			}, [b(t.$slots, "description", {}, () => [c(C(e.description), 1)], !0)], 8, Kn)) : a("v-if", !0)]),
			t.$slots.actions ? (_(), o("div", qn, [b(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-cf274d89"]]), Yn = {
	key: 0,
	class: "ui-section__header"
}, Xn = { class: "ui-section__heading" }, Zn = { key: 0 }, Qn = { key: 1 }, $n = {
	key: 0,
	class: "ui-section__actions"
}, er = ["id"], tr = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiSection",
	props: /*@__PURE__*/ f({
		title: {},
		description: {},
		icon: {},
		appearance: { default: "plain" },
		collapsible: {
			type: Boolean,
			default: !1
		}
	}, {
		open: {
			type: Boolean,
			default: !0
		},
		openModifiers: {}
	}),
	emits: ["update:open"],
	setup(e) {
		let t = E(e, "open"), n = T();
		return (r, u) => (_(), i(w(V), {
			as: "section",
			class: "ui-section",
			"data-ui": "section",
			"data-appearance": e.appearance,
			open: !e.collapsible || t.value,
			"onUpdate:open": u[0] ||= (e) => t.value = e
		}, {
			default: j(() => [
				e.title || e.description || r.$slots.actions || e.collapsible ? (_(), o("header", Yn, [s("div", Xn, [e.title ? (_(), o("h2", Zn, [e.icon ? (_(), i(x(e.icon), {
					key: 0,
					size: 18,
					"aria-hidden": "true"
				})) : a("v-if", !0), c(C(e.title), 1)])) : a("v-if", !0), e.description ? (_(), o("p", Qn, C(e.description), 1)) : a("v-if", !0)]), r.$slots.actions || e.collapsible ? (_(), o("div", $n, [b(r.$slots, "actions", {}, void 0, !0), e.collapsible ? (_(), i(w(re), {
					key: 0,
					"as-child": ""
				}, {
					default: j(() => [l(K, {
						appearance: "ghost",
						density: "compact",
						"icon-only": "",
						"aria-label": e.title,
						"aria-controls": w(n)
					}, {
						default: j(() => [l(w(U), {
							class: "ui-section__chevron",
							size: 16,
							"aria-hidden": "true"
						})]),
						_: 1
					}, 8, ["aria-label", "aria-controls"])]),
					_: 1
				})) : a("v-if", !0)])) : a("v-if", !0)])) : a("v-if", !0),
				a(" 保持表单与列表挂载；折叠仅隐藏内容，不重置输入或业务状态。 "),
				e.collapsible ? (_(), i(w(B), {
					key: 1,
					"as-child": "",
					"force-mount": ""
				}, {
					default: j(() => [M(s("div", {
						id: w(n),
						class: "ui-section__content"
					}, [b(r.$slots, "default", {}, void 0, !0)], 8, er), [[k, t.value]])]),
					_: 3
				})) : b(r.$slots, "default", {}, void 0, !0, 2)
			]),
			_: 3
		}, 8, ["data-appearance", "open"]));
	}
}), [["__scopeId", "data-v-8d0608c2"]]), nr = {
	class: "ui-form-row",
	"data-ui": "form-row"
}, rr = { class: "ui-form-row__body" }, ir = ["for"], ar = ["id"], or = { class: "ui-form-row__control" }, sr = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiFormRow",
	props: {
		label: {},
		description: {},
		icon: {},
		id: {}
	},
	setup(e) {
		let t = e, n = T();
		return (r, l) => (_(), o("div", nr, [s("div", rr, [s("label", { for: t.id ?? w(n) }, [e.icon ? (_(), i(x(e.icon), {
			key: 0,
			size: 18,
			"aria-hidden": "true"
		})) : a("v-if", !0), c(C(e.label), 1)], 8, ir), e.description ? (_(), o("p", {
			key: 0,
			id: `${t.id ?? w(n)}-description`
		}, C(e.description), 9, ar)) : a("v-if", !0)]), s("div", or, [b(r.$slots, "default", {
			id: t.id ?? w(n),
			describedby: e.description ? `${t.id ?? w(n)}-description` : void 0
		}, void 0, !0)])]));
	}
}), [["__scopeId", "data-v-09c39235"]]), cr = {}, lr = {
	class: "ui-toolbar",
	"data-ui": "toolbar"
}, ur = { class: "ui-toolbar__content" }, dr = {
	key: 0,
	class: "ui-toolbar__actions"
};
function fr(e, t) {
	return _(), o("div", lr, [s("div", ur, [b(e.$slots, "default", {}, void 0, !0)]), e.$slots.actions ? (_(), o("div", dr, [b(e.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)]);
}
var pr = /*#__PURE__*/ G(cr, [["render", fr], ["__scopeId", "data-v-fe93da01"]]), mr = ["value", "aria-label"], hr = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiProgress",
	props: {
		label: {},
		value: {}
	},
	setup(e) {
		return (t, n) => (_(), o("progress", {
			class: "ui-progress",
			"data-ui": "progress",
			value: e.value,
			max: "100",
			"aria-label": e.label
		}, null, 8, mr));
	}
}), [["__scopeId", "data-v-13af356b"]]), gr = ["data-state", "data-density"], _r = { class: "ui-progress-row__heading" }, vr = ["title"], yr = ["aria-label"], br = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiProgressRow",
	props: {
		density: { default: "default" },
		showProgress: {
			type: Boolean,
			default: !0
		},
		statusDisplay: { default: "percent" },
		label: {},
		state: {},
		statusLabel: {},
		value: {}
	},
	setup(e) {
		let n = e, l = {
			pending: Xe,
			running: nt,
			succeeded: Qe,
			failed: $e
		}, u = r(() => n.state === "succeeded" ? 100 : n.value === void 0 ? void 0 : Math.min(100, Math.max(0, n.value)));
		return (n, r) => (_(), o("div", {
			class: "ui-progress-row",
			"data-ui": "progress-row",
			"data-state": e.state,
			"data-density": e.density
		}, [
			s("div", _r, [
				(_(), i(x(l[e.state]), {
					size: e.density === "compact" ? 15 : 18,
					class: "ui-progress-row__icon",
					"aria-hidden": "true"
				}, null, 8, ["size"])),
				s("span", {
					class: "ui-progress-row__label",
					title: e.label
				}, C(e.label), 9, vr),
				s("span", {
					class: "ui-progress-row__status",
					"aria-label": e.statusLabel
				}, [e.statusDisplay === "percent" && u.value !== void 0 ? (_(), o(t, { key: 0 }, [c(C(u.value) + "%", 1)], 64)) : (_(), o(t, { key: 1 }, [c(C(e.statusLabel), 1)], 64))], 8, yr)
			]),
			e.showProgress ? (_(), i(hr, {
				key: 0,
				label: e.label,
				value: u.value
			}, null, 8, ["label", "value"])) : a("v-if", !0),
			b(n.$slots, "default", {}, void 0, !0)
		], 8, gr));
	}
}), [["__scopeId", "data-v-840f5068"]]), xr = { class: "ui-loading" }, Sr = {
	key: 0,
	class: "ui-loading__caption",
	role: "status"
}, Cr = /*#__PURE__*/ G(/* @__PURE__ */ u({
	__name: "UiLoadingTiles",
	props: {
		label: {},
		icons: { default: () => [
			rt,
			at,
			et,
			it
		] },
		active: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let n = ee("tiles"), { play: r, enabled: c } = J(), l = {
			opacity: .65,
			transform: "translateY(0)"
		}, u = {
			opacity: 1,
			transform: "translateY(-5px)"
		};
		return A([
			n,
			c,
			() => e.active,
			() => e.icons
		], ([e, t, n], i, a) => {
			if (!e || !t || !n || !e.animate) return;
			let o = [...e.querySelectorAll(".ui-loading-tiles__tile")];
			if (!o.length) return;
			let s = o.map((e, t) => Array.from({ length: o.length * 2 + 1 }, (e, n) => n === t * 2 + 1 ? u : l)), c = !1, d, f = [];
			function p() {
				c || (f = o.map((e, t) => r(e, s[t], 2600, t ? void 0 : m)));
			}
			function m() {
				c || (d = requestAnimationFrame(p));
			}
			a(() => {
				c = !0, d !== void 0 && cancelAnimationFrame(d);
				for (let e of f) e();
			}), p();
		}, { flush: "post" }), (r, c) => (_(), o("div", xr, [s("div", {
			ref_key: "tiles",
			ref: n,
			class: "ui-loading-tiles",
			"aria-hidden": "true"
		}, [(_(!0), o(t, null, y(e.icons, (e, t) => (_(), o("span", {
			key: t,
			class: "ui-loading-tiles__tile"
		}, [(_(), i(x(e), { "stroke-width": 1.5 }))]))), 128))], 512), b(r.$slots, "caption", {}, () => [e.label ? (_(), o("p", Sr, C(e.label), 1)) : a("v-if", !0)], !0)]));
	}
}), [["__scopeId", "data-v-6e6f4bb8"]]), wr = e.enum([
	"UI_THEME_DUPLICATE",
	"UI_THEME_INVALID_TOKEN",
	"UI_THEME_NOT_INSTALLED",
	"UI_THEME_UNAVAILABLE"
]), Tr = wr.enum;
export { sn as UiActionCard, hn as UiBadge, K as UiButton, Fn as UiCard, cn as UiContextMenu, $t as UiDialog, In as UiDropdownMenu, bn as UiEmptyState, Tr as UiErrorCode, wr as UiErrorCodeSchema, vt as UiField, sr as UiFormRow, Ct as UiInput, Bn as UiList, Jn as UiListItem, Cr as UiLoadingTiles, hr as UiProgress, br as UiProgressRow, qt as UiResizeHandle, $ as UiScrollArea, tr as UiSection, Dt as UiSelect, un as UiSlider, ln as UiSwitch, fn as UiTabs, It as UiToastStack, pr as UiToolbar, Q as UiTransition, Bt as uiResizeEdges, rn as vSelectableAction };
