import { z } from 'zod';
import { MaybeRefOrGetter, Component, ComputedRef, MaybeRef } from 'vue';
import { UseWebSocketOptions, UseWebSocketReturn } from '@vueuse/core';

declare const LogLevelSchema: z.ZodEnum<{
    fatal: "fatal";
    error: "error";
    warn: "warn";
    info: "info";
    debug: "debug";
    trace: "trace";
}>;
type LogLevel = z.infer<typeof LogLevelSchema>;
/** 只接收有限的平面参数，不接收 Error、请求、配置或任意嵌套对象。 */
declare const LogParamsSchema: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>;
type LogParams = z.infer<typeof LogParamsSchema>;
/** 插件只描述事件；来源、插件身份、记录 ID 和时间由宿主生成。 */
declare const PluginLogInputSchema: z.ZodObject<{
    level: z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>;
    code: z.ZodString;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>>;
    correlationId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
type PluginLogInput = z.infer<typeof PluginLogInputSchema>;
/** ctx.app.log 仅提供本端记录，不提供通知、订阅、传输或历史读取。
 * 无效事件或卸载后的调用直接忽略，日志故障不影响插件业务，不返回失败结果。
 */
interface PluginLogApi {
    report(event: PluginLogInput): void;
}

/** 插件作用域的生命周期由运行时管理。 */
interface PluginScopeApi {
    readonly signal: AbortSignal;
    /** 登记当前作用域的资源清理。返回值用于撤销有效作用域中的登记。失效后登记会直接安排清理。 */
    onDispose(cleanup: () => void | Promise<void>): () => void;
}

declare const PluginBrowserLogInputSchema: z.ZodObject<{
    level: z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>;
    code: z.ZodString;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>>;
    correlationId: z.ZodOptional<z.ZodString>;
    userVisible: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
type PluginBrowserLogInput = z.infer<typeof PluginBrowserLogInputSchema>;
type PluginLogMessages = Readonly<Record<string, Readonly<Record<string, string>>>>;
interface PluginBrowserLogApi extends PluginLogApi {
    report(event: PluginBrowserLogInput): void;
    /** 按语言和提示码登记资源，随当前插件实例释放。 */
    registerMessages(messages: PluginLogMessages): () => void;
}

interface AuthLoginActionApi {
    /** 与该插件的后端登录方式匹配的同源地址。 */
    readonly baseURL: string;
    readonly signal: AbortSignal;
    /** 通知宿主重新读取服务端会话。整页跳转在页面返回时由宿主启动流程确认。 */
    onComplete(): Promise<void>;
}
interface AuthLoginContribution {
    /** 与同一插件在后端登记的登录方式 ID 相同。 */
    readonly id: string;
    readonly label: MaybeRefOrGetter<string>;
    readonly icon?: Component;
    start(action: AuthLoginActionApi): void | Promise<void>;
}

type UiThemeMode = 'light' | 'dark';
/**
 * 开放的主题变量覆盖表；空对象合法，不要求主题重复提供所有内置默认值。
 * 内置 UI 使用的 --ui-* 变量默认允许主题覆盖，新增变量不需要修改本类型或登记清单。
 * 通用变量使用 --ui-primary 等语义名称；组件变量使用 --ui-button-background 等组件前缀。
 * 值为单个 CSS 自定义属性的值，例如颜色、阴影、字体或 var(...)，不传选择器和整段样式表。
 * 未覆盖的变量沿用相同 mode 的内置默认值；组件变量可通过 var(...) 引用通用变量。
 * 主题只覆盖外观，不替换组件结构、交互或业务逻辑，也不公开内部 DOM 和 CSS 类名。
 */
type UiThemeTokens = Readonly<Record<`--ui-${string}`, string>>;
interface UiTheme {
    /** 当前注册表内唯一标识；命名空间及提供方身份由上层装配，不在基础 UI 中推断。 */
    readonly id: string;
    /** 随本体语言响应式变化，不由主题维护第二套语言设置。 */
    readonly label: MaybeRefOrGetter<string>;
    /** 决定未覆盖变量使用哪套内置默认值。 */
    readonly mode: UiThemeMode;
    /** 仅提供本主题需要改变的变量；内置组件 CSS 由 UI 自身统一维护和导出。 */
    readonly tokens: UiThemeTokens;
}

interface UiMenuItem {
    id: string;
    label: string;
    icon?: Component;
    disabled?: boolean;
    tone?: 'neutral' | 'danger';
    /** Visually separate the following action group without creating a selectable row. */
    separatorBefore?: boolean;
}
/** 点击触发的动作菜单，与选择框和右键菜单互斥；业务只接收稳定的选项 ID。 */
interface UiDropdownMenuProps {
    items: readonly UiMenuItem[];
    disabled?: boolean;
    align?: 'start' | 'center' | 'end';
    /** 默认直接展开。 */
    transition?: 'none' | 'fade';
}

/** 可选语义状态，颜色由宿主主题决定，文本由插件国际化。 */
interface WindowTabStatus {
    readonly tone: 'neutral' | 'success' | 'warning' | 'info' | 'danger';
    readonly label: string;
    readonly busy?: boolean;
}
interface WindowTab {
    readonly id: string;
    readonly label: string;
    readonly status?: WindowTabStatus;
    readonly disabled?: boolean;
    readonly closable?: boolean;
    readonly menu?: readonly UiMenuItem[];
}
interface WindowTabsOptions {
    readonly items: MaybeRefOrGetter<readonly WindowTab[]>;
    readonly activeId: MaybeRefOrGetter<string | undefined>;
    readonly addLabel?: MaybeRefOrGetter<string>;
    onSelect(id: string): void | Promise<void>;
    onClose?(id: string): void | Promise<void>;
    onAdd?(): void | Promise<void>;
    onMenuSelect?(id: string, menuId: string): void | Promise<void>;
}
interface WindowAction {
    readonly id: string;
    readonly label: string;
    readonly icon?: Component;
    readonly disabled?: boolean;
    readonly items?: readonly UiMenuItem[];
    readonly menuTransition?: UiDropdownMenuProps['transition'];
}
interface WindowActionsOptions {
    readonly items: MaybeRefOrGetter<readonly WindowAction[]>;
    onSelect(id: string, menuId?: string): void | Promise<void>;
}
interface PluginWindowState {
    readonly focused: boolean;
    readonly mode: 'normal' | 'minimized' | 'maximized';
}
/** 本次应用窗口的操作和顶栏贡献，登记随窗口关闭撤销。 */
interface PluginWindowApi extends PluginViewApi {
    readonly state: ComputedRef<PluginWindowState>;
    registerTabs(options: WindowTabsOptions): () => void;
    registerActions(options: WindowActionsOptions): () => void;
    focus(): void;
    minimize(): void;
    maximize(): void;
    restore(): void;
}
interface PluginWindowProps extends PluginComponentProps {
    readonly view: PluginWindowApi;
}
interface PluginWindowLauncherApi {
    /** 打开本插件的应用。单窗口应用已有实例时恢复并聚焦。 */
    open(applicationId: string): void;
}

/** 服务器返回的 HTTP 失败。请求取消和网络失败保留 Fetch 的异常语义。 */
declare class PluginHttpError extends Error {
    readonly status: number;
    readonly code: string;
    readonly name = "PluginHttpError";
    constructor(status: number, code: string);
}
interface PluginHttpClientApi {
    url(path: string): string;
    request(path: string, options?: RequestInit): Promise<Response>;
    json<Schema extends z.ZodType>(path: string, schema: Schema, options?: RequestInit): Promise<z.output<Schema>>;
}

type PluginStateUnconfirmed = 'disconnected' | 'unavailable' | 'resync' | 'invalid';
interface PluginStateObserver<Value> {
    updated(value: Value): void;
    unconfirmed?(reason: PluginStateUnconfirmed): void;
}
interface PluginStateClientApi {
    /** 在宿主的会话连接订阅本插件主题。每项订阅可单独撤销。 */
    subscribe<Schema extends z.ZodType>(name: string, schema: Schema, observer: PluginStateObserver<z.output<Schema>>, signal?: AbortSignal): () => void;
}

interface PluginTaskOptions {
    readonly name?: string;
    readonly signal?: AbortSignal;
    /** 普通关闭等待任务，强制关闭通过视图信号取消。 */
    readonly view?: PluginViewApi;
}
interface PluginTaskEvent {
    readonly id: string;
    readonly name?: string;
    readonly startedAt: number;
    readonly durationMs?: number;
    readonly mode: 'run' | 'background';
    readonly outcome?: 'succeeded' | 'failed' | 'cancelled';
}
interface PluginTasksApi {
    run<Result>(work: (signal: AbortSignal) => Result | Promise<Result>, options?: PluginTaskOptions): Promise<Result>;
    background(name: string, work: (signal: AbortSignal) => unknown, options?: Pick<PluginTaskOptions, 'signal'>): void;
    on(event: 'started' | 'settled', listener: (event: PluginTaskEvent) => void): () => void;
}

type PluginWsClientOptions = Pick<UseWebSocketOptions, 'protocols' | 'autoReconnect' | 'onConnected' | 'onDisconnected' | 'onError' | 'onMessage'> & {
    readonly signal?: AbortSignal;
    readonly binaryType?: BinaryType;
};
type Message = string | ArrayBuffer | Blob;
interface PluginWsClientApi {
    url(path: string): string;
    /** 自动重连可选。断线期间发送直接返回 false。 */
    connect(path: string, options?: PluginWsClientOptions): Pick<UseWebSocketReturn<Message>, 'data' | 'status' | 'send' | 'close'>;
}

declare const PluginServiceReferenceSchema: z.ZodReadonly<z.ZodTuple<[z.ZodString, z.ZodString], null>>;
type PluginServiceReference = z.infer<typeof PluginServiceReferenceSchema>;
declare const PluginServiceSelectionSchema: z.ZodReadonly<z.ZodRecord<z.ZodString, z.ZodReadonly<z.ZodTuple<[z.ZodString, z.ZodString], null>>>>;
type PluginServiceSelection = z.infer<typeof PluginServiceSelectionSchema>;
type Provider<Services> = Extract<keyof Services, string>;
type ServiceName<Services, Owner extends Provider<Services>> = Extract<keyof Services[Owner], string>;
type DeclaredServiceReference<Services> = {
    [Owner in Provider<Services>]: {
        [Name in ServiceName<Services, Owner>]: readonly [Owner, Name];
    }[ServiceName<Services, Owner>];
}[Provider<Services>];
type ServiceRegistration<Services> = {
    [Owner in Provider<Services>]: {
        [Name in ServiceName<Services, Owner>]: [name: Name, service: Services[Owner][Name]];
    }[ServiceName<Services, Owner>];
}[Provider<Services>];
type SelectedServices<Services, Selection extends PluginServiceSelection> = {
    readonly [Alias in keyof Selection]: Selection[Alias] extends readonly [infer Owner, infer Name] ? Owner extends Provider<Services> ? Name extends ServiceName<Services, Owner> ? Services[Owner][Name] : never : never : never;
};

declare const PluginReadinessUpdateSchema: z.ZodDiscriminatedUnion<[z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"ready">;
}, z.core.$strict>>, z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"pending">;
    reason: z.ZodReadonly<z.ZodObject<{
        code: z.ZodLiteral<"PLUGIN_CONFIGURATION_REQUIRED">;
        applicationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>>], "state">;
type PluginReadinessUpdate = z.infer<typeof PluginReadinessUpdateSchema>;
declare const PluginReadinessSchema: z.ZodDiscriminatedUnion<[z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"ready">;
}, z.core.$strict>>, z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"pending">;
    reason: z.ZodOptional<z.ZodReadonly<z.ZodObject<{
        code: z.ZodLiteral<"PLUGIN_CONFIGURATION_REQUIRED">;
        applicationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>>], "state">;
type PluginReadiness = z.infer<typeof PluginReadinessSchema>;
declare const PluginRuntimeInfoSchema: z.ZodReadonly<z.ZodObject<{
    pluginId: z.ZodString;
    version: z.ZodString;
    runtime: z.ZodEnum<{
        running: "running";
        failed: "failed";
        starting: "starting";
        stopping: "stopping";
        stopped: "stopped";
    }>;
    readiness: z.ZodDiscriminatedUnion<[z.ZodReadonly<z.ZodObject<{
        state: z.ZodLiteral<"ready">;
    }, z.core.$strict>>, z.ZodReadonly<z.ZodObject<{
        state: z.ZodLiteral<"pending">;
        reason: z.ZodOptional<z.ZodReadonly<z.ZodObject<{
            code: z.ZodLiteral<"PLUGIN_CONFIGURATION_REQUIRED">;
            applicationId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>], "state">;
    issues: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodDiscriminatedUnion<[z.ZodObject<{
        code: z.ZodEnum<{
            PLUGIN_DEPENDENCY_NOT_RUNNING: "PLUGIN_DEPENDENCY_NOT_RUNNING";
            PLUGIN_DEPENDENCY_NOT_READY: "PLUGIN_DEPENDENCY_NOT_READY";
        }>;
        pluginId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        code: z.ZodLiteral<"PLUGIN_DEPENDENCY_VERSION_MISMATCH">;
        pluginId: z.ZodString;
        required: z.ZodString;
        actual: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        code: z.ZodEnum<{
            PLUGIN_DEPENDENCY_CYCLE: "PLUGIN_DEPENDENCY_CYCLE";
            PLUGIN_DEPENDENCY_SETUP_FAILED: "PLUGIN_DEPENDENCY_SETUP_FAILED";
            PLUGIN_START_FAILED: "PLUGIN_START_FAILED";
            PLUGIN_STOP_FAILED: "PLUGIN_STOP_FAILED";
        }>;
        pluginId: z.ZodString;
    }, z.core.$strict>], "code">>>>;
}, z.core.$strict>>;
type PluginRuntimeInfo = z.infer<typeof PluginRuntimeInfoSchema>;

/** 浏览器宿主为插件实例装配的能力。 */
interface PluginAppApi {
    readonly http: PluginHttpClientApi;
    readonly log: PluginBrowserLogApi;
    readonly state: PluginStateClientApi;
    readonly tasks: PluginTasksApi;
    readonly ws: PluginWsClientApi;
    readonly windows: PluginWindowLauncherApi;
}
/** 插件通过 Browser SDK 按包名和服务名扩充此接口。 */
interface PluginServicesApi {
}
type PluginBackendState = Pick<PluginRuntimeInfo, 'runtime' | 'readiness'>;
interface PluginSelfApi {
    readonly id: string;
    readonly backend: PluginBackendState | null;
    readonly readiness: {
        readonly value: PluginReadiness;
        set(update: PluginReadinessUpdate): void;
    };
}
interface PluginServiceScopeApi extends PluginScopeApi {
    provide(...registration: ServiceRegistration<PluginServicesApi>): () => void;
}
interface PluginDependencyScopeApi<Services = Record<string, unknown>> extends PluginServiceScopeApi {
    readonly plugin: Readonly<Services>;
}
type Cleanup = Parameters<PluginScopeApi['onDispose']>[0];
/** 浏览器插件运行时交给 activate 的上下文。 */
interface PluginContextApi extends PluginServiceScopeApi {
    readonly app: PluginAppApi;
    readonly self: PluginSelfApi;
    /** 激活期间声明贡献。入口执行成功后由宿主发布，停用时自动撤销。 */
    contribute(contributions: PluginContributions): void;
    use<const Selection extends Readonly<Record<string, DeclaredServiceReference<PluginServicesApi>>>>(services: Selection, setup: (scope: PluginDependencyScopeApi<SelectedServices<PluginServicesApi, Selection>>) => void | Cleanup | Promise<void | Cleanup>): () => void;
}
/** 浏览器插件入口。每次启用注入新作用域并重新执行 activate。 */
interface PluginModuleApi {
    activate(context: PluginContextApi): void | Promise<void>;
    /** 仅对成功激活的实例执行。调用时对应的信号已取消。 */
    deactivate?(context: PluginContextApi): void | Promise<void>;
}

interface PluginComponentProps {
    readonly context: PluginContextApi;
    /** 每次组件挂载有独立的信号与资源清理，切换应用视图时仍保留插件实例。 */
    readonly view: PluginViewApi;
}
interface PluginComponentContribution {
    /** 在当前插件的同类贡献内唯一。宿主负责附加插件身份。 */
    readonly id: string;
    readonly label: MaybeRefOrGetter<string>;
    readonly component: Component<PluginComponentProps>;
}
interface PluginApplicationTileProps extends PluginComponentProps {
    readonly size: {
        readonly columns: number;
        readonly rows: number;
    };
    open(): void;
}
interface PluginApplicationTileContribution {
    readonly component: Component<PluginApplicationTileProps>;
    /** 默认在 1×1 显示宿主启动图标。 */
    readonly showAtIconSize?: boolean;
}
interface PluginApplicationContribution extends Omit<PluginComponentContribution, 'component' | 'label'> {
    /** 函数形式可使用宿主当前语言。未提供语言时返回默认名称。 */
    readonly label: MaybeRef<string> | ((locale?: string) => string);
    readonly component: Component<PluginWindowProps> | Component<PluginComponentProps>;
    /** 提前读取首个窗口所需的模块。与组件加载器共用请求，随插件实例失效。 */
    preload?(): Promise<unknown>;
    /** 应用启动入口与窗口标题共用的图标。 */
    readonly icon?: Component;
    readonly multipleWindows?: boolean;
    readonly tile?: PluginApplicationTileContribution;
    readonly defaultWindowSize?: {
        readonly width: number;
        readonly height: number;
    };
    readonly scrollMode?: 'content' | 'window';
    readonly scrollbarGutter?: 'auto' | 'stable';
}
interface PluginContributions {
    readonly applications?: readonly PluginApplicationContribution[];
    readonly widgets?: readonly PluginComponentContribution[];
    readonly login?: readonly AuthLoginContribution[];
    readonly themes?: readonly UiTheme[];
}

interface PluginViewCloseEvent {
    readonly signal: AbortSignal;
    readonly defaultPrevented: boolean;
    preventDefault(): void;
}
/** 关闭检查属于本次挂载。停用插件或退出会话时，宿主可以直接撤销视图。 */
interface PluginViewApi extends PluginScopeApi {
    onBeforeClose(check: (event: PluginViewCloseEvent) => void | Promise<void>): () => void;
    requestClose(): Promise<boolean>;
}

declare const HttpProblemCodeSchema: z.ZodEnum<{
    HTTP_INVALID_REQUEST: "HTTP_INVALID_REQUEST";
    HTTP_ORIGIN_DENIED: "HTTP_ORIGIN_DENIED";
    HTTP_NOT_FOUND: "HTTP_NOT_FOUND";
    HTTP_PAYLOAD_TOO_LARGE: "HTTP_PAYLOAD_TOO_LARGE";
    HTTP_UNSUPPORTED_MEDIA_TYPE: "HTTP_UNSUPPORTED_MEDIA_TYPE";
    HTTP_INTERNAL_ERROR: "HTTP_INTERNAL_ERROR";
    HTTP_ROUTE_CLOSED: "HTTP_ROUTE_CLOSED";
}>;
type HttpProblemCode = z.infer<typeof HttpProblemCodeSchema>;
declare const HttpProblemSchema: z.ZodObject<{
    type: z.ZodLiteral<"about:blank">;
    status: z.ZodNumber;
    code: z.ZodString;
}, z.core.$strip>;
type HttpProblem = z.infer<typeof HttpProblemSchema>;

export { HttpProblemCodeSchema, HttpProblemSchema, LogLevelSchema, LogParamsSchema, PluginHttpError, PluginLogInputSchema };
export type { AuthLoginActionApi, AuthLoginContribution, HttpProblem, HttpProblemCode, LogLevel, LogParams, PluginAppApi, PluginApplicationContribution, PluginApplicationTileContribution, PluginApplicationTileProps, PluginBackendState, PluginBrowserLogApi, PluginBrowserLogInput, PluginComponentContribution, PluginComponentProps, PluginContextApi, PluginContributions, PluginDependencyScopeApi, PluginHttpClientApi, PluginLogApi, PluginLogInput, PluginLogMessages, PluginModuleApi, PluginReadiness, PluginReadinessUpdate, PluginScopeApi, PluginSelfApi, PluginServiceReference, PluginServiceSelection, PluginServicesApi, PluginStateClientApi, PluginStateObserver, PluginStateUnconfirmed, PluginTaskEvent, PluginTaskOptions, PluginTasksApi, PluginViewApi, PluginViewCloseEvent, PluginWindowApi, PluginWindowLauncherApi, PluginWindowProps, PluginWindowState, PluginWsClientApi, PluginWsClientOptions, WindowAction, WindowActionsOptions, WindowTab, WindowTabStatus, WindowTabsOptions };
