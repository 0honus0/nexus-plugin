import { z as e } from "zod";
import { Fragment as t, Transition as n, computed as r, createBlock as i, createCommentVNode as a, createElementBlock as o, createElementVNode as s, createTextVNode as c, createVNode as l, defineComponent as u, getCurrentInstance as d, inject as f, mergeModels as p, mergeProps as m, nextTick as h, normalizeClass as g, onScopeDispose as _, openBlock as v, ref as y, renderList as b, renderSlot as x, resolveDynamicComponent as S, shallowRef as C, toDisplayString as w, unref as T, useId as E, useModel as D, useSlots as O, useTemplateRef as k, vModelDynamic as A, vShow as j, watch as M, withCtx as N, withDirectives as P, withModifiers as F } from "vue";
import { animateMini as I } from "motion-v";
import { unrefElement as L, useEventListener as ee, useMediaQuery as te, usePointerSwipe as ne, usePreferredReducedMotion as R, useResizeObserver as re, useStorage as z, useWindowSize as B } from "@vueuse/core";
import { CollapsibleContent as V, CollapsibleRoot as H, CollapsibleTrigger as ie, ContextMenuContent as ae, ContextMenuItem as U, ContextMenuPortal as W, ContextMenuRoot as oe, ContextMenuSeparator as se, ContextMenuTrigger as ce, DialogClose as G, DialogContent as le, DialogDescription as ue, DialogOverlay as de, DialogPortal as fe, DialogRoot as pe, DialogTitle as me, DropdownMenuContent as he, DropdownMenuItem as ge, DropdownMenuPortal as _e, DropdownMenuRoot as ve, DropdownMenuSeparator as ye, DropdownMenuTrigger as be, Primitive as xe, SelectContent as Se, SelectIcon as Ce, SelectItem as we, SelectItemText as Te, SelectPortal as Ee, SelectRoot as De, SelectScrollDownButton as Oe, SelectScrollUpButton as ke, SelectTrigger as Ae, SelectValue as je, SelectViewport as Me, SliderRange as Ne, SliderRoot as Pe, SliderThumb as Fe, SliderTrack as Ie, SwitchRoot as Le, SwitchThumb as Re, TabsContent as ze, TabsList as Be, TabsRoot as Ve, TabsTrigger as He, ToastClose as Ue, ToastDescription as We, ToastProvider as Ge, ToastRoot as Ke, ToastViewport as qe, VisuallyHidden as Je } from "reka-ui";
import { ChevronDown as K, ChevronUp as Ye, Circle as Xe, CircleAlert as Ze, CircleCheck as Qe, CircleX as $e, Folder as et, Info as tt, LoaderCircle as nt, PanelsTopLeft as rt, Puzzle as it, Terminal as at, X as ot } from "@lucide/vue";
import st from "interactjs";
// src/ui/browser/components/UiButton.vue?vue&type=script&setup=true&lang.ts
var ct = [
	"data-appearance",
	"data-tone",
	"data-density",
	"type",
	"disabled",
	"aria-busy",
	"data-loading-animation",
	"data-loading-placement"
], lt = { class: "ui-button__content" }, ut = {
	key: 0,
	class: "ui-button__leading"
}, dt = { class: "ui-button__leading-content" }, ft = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, pt = {
	key: 0,
	class: "ui-button__loader",
	"aria-hidden": "true"
}, mt = /*@__PURE__*/ u({
	__name: "UiButton",
	props: {
		appearance: { default: "soft" },
		tone: { default: "neutral" },
		density: { default: "default" },
		type: { default: "button" },
		disabled: {
			type: Boolean,
			default: !1
		},
		loading: {
			type: Boolean,
			default: !1
		},
		loadingAnimation: { default: "icon" },
		block: {
			type: Boolean,
			default: !1
		},
		iconOnly: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		let t = e, n = O();
		function r() {
			return t.loadingAnimation === "icon" && (t.iconOnly || !!n.leading);
		}
		function i() {
			return !t.iconOnly && n.leading ? "leading" : "content";
		}
		return (e, n) => (v(), o("button", {
			"data-ui": "button",
			"data-appearance": t.appearance,
			"data-tone": t.tone,
			"data-density": t.density,
			type: t.type,
			disabled: t.disabled || t.loading,
			"aria-busy": t.loading || void 0,
			onClickCapture: n[0] ||= (e) => {
				e.currentTarget.getAttribute("aria-disabled") === "true" && (e.preventDefault(), e.stopImmediatePropagation());
			},
			"data-loading-animation": t.loading ? r() ? "icon" : "spinner" : void 0,
			"data-loading-placement": t.loading && !r() ? i() : void 0,
			class: g(["ui-button", {
				"ui-button--block": t.block,
				"ui-button--icon-only": t.iconOnly
			}])
		}, [s("span", lt, [
			e.$slots.leading ? (v(), o("span", ut, [s("span", dt, [x(e.$slots, "leading", {}, void 0, !0)]), t.loading && !r() && i() === "leading" ? (v(), o("span", ft, [...n[1] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)])) : a("v-if", !0),
			x(e.$slots, "default", {}, void 0, !0),
			x(e.$slots, "trailing", {}, void 0, !0)
		]), t.loading && !r() && i() === "content" ? (v(), o("span", pt, [...n[2] ||= [s("span", { class: "ui-button__spinner" }, null, -1)]])) : a("v-if", !0)], 42, ct));
	}
}), q = (e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
}, J = /*#__PURE__*/ q(mt, [["__scopeId", "data-v-eae79e1d"]]), ht = {
	class: "ui-field",
	"data-ui": "field"
}, gt = ["for"], _t = ["id"], vt = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiField",
	props: {
		label: {},
		hint: {},
		id: {}
	},
	setup(e) {
		let t = e, n = E();
		return (r, i) => (v(), o("div", ht, [
			s("label", { for: t.id ?? T(n) }, w(e.label), 9, gt),
			x(r.$slots, "default", {
				id: t.id ?? T(n),
				describedby: e.hint ? `${t.id ?? T(n)}-hint` : void 0
			}, void 0, !0),
			e.hint ? (v(), o("p", {
				key: 0,
				id: `${t.id ?? T(n)}-hint`
			}, w(e.hint), 9, _t)) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-2f372308"]]), yt = [
	"data-density",
	"data-invalid",
	"data-disabled"
], bt = {
	key: 0,
	class: "ui-input__accessory"
}, xt = [
	"id",
	"type",
	"disabled"
], St = {
	key: 1,
	class: "ui-input__accessory"
}, Ct = /*#__PURE__*/ q(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiInput",
	props: /*@__PURE__*/ p({
		type: { default: "text" },
		disabled: { type: Boolean },
		density: { default: "default" },
		invalid: { type: Boolean }
	}, {
		modelValue: { default: "" },
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = D(e, "modelValue"), n = E();
		return (r, i) => (v(), o("div", {
			class: "ui-input",
			"data-ui": "input",
			"data-density": e.density,
			"data-invalid": e.invalid || void 0,
			"data-disabled": e.disabled || void 0
		}, [
			r.$slots.leading ? (v(), o("span", bt, [x(r.$slots, "leading", {}, void 0, !0)])) : a("v-if", !0),
			P(s("input", m({
				...r.$attrs,
				...e.invalid ? { "aria-invalid": !0 } : {}
			}, {
				id: typeof r.$attrs.id == "string" && r.$attrs.id ? r.$attrs.id : T(n),
				"onUpdate:modelValue": i[0] ||= (e) => t.value = e,
				type: e.type,
				disabled: e.disabled
			}), null, 16, xt), [[A, t.value]]),
			r.$slots.trailing ? (v(), o("span", St, [x(r.$slots, "trailing", {}, void 0, !0)])) : a("v-if", !0)
		], 8, yt));
	}
}), [["__scopeId", "data-v-619d8796"]]), wt = Symbol("ui.motion"), Y = /* @__PURE__ */ new WeakMap();
function Tt(e) {
	return e.startsWith("--") ? e : e.replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
}
function X() {
	let e = R(), t = f(wt, {
		enabled: r(() => e.value !== "reduce"),
		speed: r(() => 1)
	}), n = /* @__PURE__ */ new Map();
	function i(e, r, i, a = () => {}, o = [
		.22,
		1,
		.36,
		1
	]) {
		let s = Object.keys(r.at(-1) ?? {}).filter((e) => ![
			"offset",
			"easing",
			"composite"
		].includes(e)), c = Y.get(e), l = c ? getComputedStyle(e) : void 0, u = new Map(c?.properties.map((e) => [e, l.getPropertyValue(Tt(e))]));
		if (c?.finish(), !t.enabled.value || !e.animate) return a(), () => {};
		let d = new Map(s.map((t) => {
			let n = Tt(t);
			return [n, e.style.getPropertyValue(n)];
		})), f = Object.fromEntries(s.map((e) => [e, r.map((t, n) => n === 0 && u.has(e) ? u.get(e) : t[e])])), p = I(e, f, {
			duration: i / 1e3,
			ease: o
		});
		p.speed = t.speed.value;
		let m = !1;
		function h() {
			if (!m) {
				m = !0, n.delete(p), Y.get(e)?.finish === h && Y.delete(e), p.cancel();
				for (let [t, n] of d) n ? e.style.setProperty(t, n) : e.style.removeProperty(t);
				a();
			}
		}
		return Y.set(e, {
			finish: h,
			properties: s
		}), n.set(p, h), p.finished.then(h, h), h;
	}
	return M(t.enabled, (e) => {
		if (!e) for (let e of [...n.values()]) e();
	}, { flush: "sync" }), M(t.speed, (e) => {
		for (let t of n.keys()) t.speed = e;
	}, { flush: "sync" }), _(() => {
		for (let e of [...n.values()]) e();
	}), {
		play: i,
		enabled: t.enabled
	};
}
// src/ui/browser/ui-overlay.ts
var Z;
function Et() {
	Z?.dismiss();
}
function Dt(e, t) {
	let n = !0, r = { dismiss() {
		n = !1, e.value = !1;
	} };
	return M([e, () => t?.value ?? !1], ([e, t]) => {
		e && t ? r.dismiss() : e ? (Z !== r && Z?.dismiss(), n = !0, Z = r) : Z === r && (Z = void 0);
	}, {
		immediate: !0,
		flush: "sync"
	}), _(() => {
		Z === r && (Z = void 0);
	}), {
		interactOutside() {
			n = !1;
		},
		closeAutoFocus(e) {
			n || e.preventDefault();
		},
		select(e, t) {
			r.dismiss(), e?.focus({ preventScroll: !0 }), t();
		}
	};
}
// src/ui/browser/components/UiSelect.vue?vue&type=script&setup=true&lang.ts
var Ot = "inset(-48px)", kt = /*#__PURE__*/ q(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSelect",
	props: /*@__PURE__*/ p({
		options: {},
		placeholder: {},
		name: {},
		required: {
			type: Boolean,
			default: !1
		},
		disabled: {
			type: Boolean,
			default: !1
		},
		invalid: {
			type: Boolean,
			default: !1
		},
		block: {
			type: Boolean,
			default: !1
		},
		density: { default: "default" },
		contentAlign: { default: "center" }
	}, {
		modelValue: {},
		modelModifiers: {},
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: ["update:modelValue", "update:open"],
	setup(e) {
		let s = D(e, "modelValue"), u = D(e, "open"), { play: d } = X(), f = e, p = r(() => f.disabled || f.options.length === 0), h = Dt(u, p), g = r(() => f.options.find((e) => e.value === s.value)?.label ?? f.placeholder ?? ""), _ = null;
		function y(e) {
			_ = e.querySelector("[data-ui=\"select-content\"]"), _?.setAttribute("data-positioning", "");
		}
		function x() {
			if (!u.value || !_) return;
			let e = _;
			_ = null, e.removeAttribute("data-positioning");
			let t = e.dataset.side === "top" ? "inset(18px -48px -48px)" : "inset(-48px -48px 18px)";
			d(e, [{
				opacity: 0,
				clipPath: t
			}, {
				opacity: 1,
				clipPath: Ot
			}], 150);
		}
		function S(e, t) {
			let n = e.querySelector("[data-ui=\"select-content\"]");
			!n || n === _ ? (_ = null, t()) : (e.setAttribute("inert", ""), e.setAttribute("aria-hidden", "true"), d(n, [{
				opacity: 1,
				clipPath: Ot
			}, {
				opacity: 0,
				clipPath: Ot
			}], 90, t));
		}
		return (e, r) => (v(), i(T(De), {
			modelValue: s.value,
			"onUpdate:modelValue": r[0] ||= (e) => s.value = e,
			open: u.value,
			"onUpdate:open": r[1] ||= (e) => u.value = e,
			name: f.name,
			required: f.required,
			disabled: p.value
		}, {
			default: N(() => [l(T(Ae), m(e.$attrs, {
				"data-ui": "select",
				"data-density": f.density,
				"aria-invalid": f.invalid || void 0,
				class: ["ui-select", { "ui-select--block": f.block }]
			}), {
				default: N(() => [l(T(je), {
					class: "ui-select__value",
					placeholder: f.placeholder
				}, {
					default: N(() => [c(w(g.value), 1)]),
					_: 1
				}, 8, ["placeholder"]), l(T(Ce), { class: "ui-select__icon" }, {
					default: N(() => [l(T(K), { size: 15 })]),
					_: 1
				})]),
				_: 1
			}, 16, [
				"data-density",
				"aria-invalid",
				"class"
			]), f.options.length ? (v(), i(T(Ee), { key: 0 }, {
				default: N(() => [l(n, {
					appear: "",
					css: !1,
					onBeforeEnter: y,
					onLeave: S
				}, {
					default: N(() => [u.value ? (v(), i(T(Se), {
						key: 0,
						"force-mount": "",
						"data-ui": "select-content",
						class: "ui-select-content",
						position: "popper",
						"body-lock": !1,
						"disable-outside-pointer-events": !1,
						onPlaced: x,
						onPointerDownOutside: T(h).interactOutside,
						onCloseAutoFocus: T(h).closeAutoFocus,
						align: f.contentAlign,
						"side-offset": 6,
						"collision-padding": 12
					}, {
						default: N(() => [
							l(T(ke), { class: "ui-select-scroll" }, {
								default: N(() => [l(T(Ye), { size: 15 })]),
								_: 1
							}),
							l(T(Me), { class: "ui-select-viewport" }, {
								default: N(() => [(v(!0), o(t, null, b(f.options, (e) => (v(), i(T(we), {
									key: e.value,
									value: e.value,
									disabled: e.disabled,
									class: "ui-select-option"
								}, {
									default: N(() => [a(" 当前值由上方选择框展示；选中语义与键盘高亮由 Reka 保留。 "), l(T(Te), { class: "ui-select-option__label" }, {
										default: N(() => [c(w(e.label), 1)]),
										_: 2
									}, 1024)]),
									_: 2
								}, 1032, ["value", "disabled"]))), 128))]),
								_: 1
							}),
							l(T(Oe), { class: "ui-select-scroll" }, {
								default: N(() => [l(T(K), { size: 15 })]),
								_: 1
							})
						]),
						_: 1
					}, 8, [
						"onPointerDownOutside",
						"onCloseAutoFocus",
						"align"
					])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})) : a("v-if", !0)]),
			_: 1
		}, 8, [
			"modelValue",
			"open",
			"name",
			"required",
			"disabled"
		]));
	}
}), [["__scopeId", "data-v-398a09bb"]]), At = e.enum(["compact", "wide"]), jt = {
	compact: {
		minWidth: 0,
		columns: 4
	},
	wide: {
		minWidth: 700,
		columns: 12
	}
};
function Mt(e) {
	return e >= jt.wide.minWidth ? "wide" : "compact";
}
// src/ui/browser/components/UiToastStack.vue?vue&type=script&setup=true&lang.ts
var Nt = ["data-tone", "data-expanded"], Pt = { class: "ui-toast__icon" }, Ft = { class: "ui-toast__content" }, It = {
	key: 0,
	class: "ui-toast__footer"
}, Lt = ["aria-expanded"], Rt = { class: "ui-toast__controls" }, zt = {
	key: 0,
	class: "ui-toast__page"
}, Bt = { "aria-hidden": "true" }, Vt = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiToastStack",
	props: {
		items: {},
		label: {},
		closeLabel: {},
		expandLabel: {},
		collapseLabel: {},
		positionLabel: {},
		duration: { default: 5e3 }
	},
	emits: ["dismiss"],
	setup(e, { emit: t }) {
		let u = e, d = t, f = te(`(width < ${jt.wide.minWidth}px)`), p = y(), _ = y(!1), b = y(), x = y(), C = y(!1), E = {
			info: tt,
			success: Qe,
			warning: Ze,
			error: Ze
		}, D = r(() => u.items.findIndex((e) => e.id === p.value)), O = r(() => u.items[D.value]), k = r(() => u.items.length - D.value), { play: A } = X(), j = !1, P, I = 0, L = () => {}, R = !1, z = 0, B = 0, V = 0;
		function H() {
			!_.value && x.value && (C.value = x.value.scrollHeight > x.value.clientHeight + 1);
		}
		re(x, H), M([() => O.value?.message, _], () => h(H)), M(() => u.items.map((e) => e.id), (e, t = []) => {
			let n = e.at(-1);
			if (n !== void 0 && !t.includes(n)) I = 0, p.value = n;
			else if (!e.includes(p.value)) {
				let n = t.indexOf(p.value);
				I = 0, p.value = e[Math.max(0, Math.min(n - 1, e.length - 1))];
			}
		}, {
			immediate: !0,
			flush: "sync"
		}), M(p, async () => {
			L(), j = !1, _.value = !1, C.value = !1, await h(), H();
		});
		function ie(e, t) {
			let n = e, r = I;
			I = 0, L = r === 0 ? A(n, [
				{
					opacity: 0,
					transform: "translateY(var(--toast-enter-y, -24px)) scale(0.86)"
				},
				{
					opacity: 1,
					transform: "translateY(var(--toast-bounce-y, 3px)) scale(1.018)",
					offset: .66
				},
				{
					opacity: 1,
					transform: "translateY(0) scale(1)"
				}
			], 320, t, [
				.22,
				1,
				.36,
				1
			]) : A(n, [{
				opacity: 0,
				transform: `translateY(${r > 0 ? -12 : 12}px) scale(0.95)`
			}, {
				opacity: 1,
				transform: "translateY(0) scale(1)"
			}], 200, t, [
				.22,
				1,
				.36,
				1
			]);
		}
		function ae(e, t) {
			let n = e, r = I;
			A(n, r === 0 ? [{
				opacity: 1,
				transform: "translateY(0) scale(1)"
			}, {
				opacity: 0,
				transform: "translateY(var(--toast-leave-y, -16px)) scale(0.92)"
			}] : [{
				opacity: 1,
				transform: "translateY(0) scale(1)"
			}, {
				opacity: 0,
				transform: `translateY(${r > 0 ? 10 : -10}px) scale(0.95)`
			}], r === 0 ? 190 : 130, t, [
				.4,
				0,
				1,
				1
			]);
		}
		function U(e) {
			if (u.items.length < 2) return;
			let t = (D.value + e + u.items.length) % u.items.length, n = b.value?.contains(document.activeElement);
			I = e, p.value = u.items[t].id, n && h(() => b.value?.focus({ preventScroll: !0 }));
		}
		function W() {
			if (!O.value) return;
			let e = b.value?.contains(document.activeElement);
			I = 0, d("dismiss", O.value.id), e && u.items.length && h(() => b.value?.focus({ preventScroll: !0 }));
		}
		function oe(e) {
			_.value = !_.value, e.currentTarget.focus({ preventScroll: !0 });
		}
		ee("keydown", (e) => {
			e.key === "Escape" && O.value && (e.preventDefault(), e.stopPropagation(), W());
		}, { capture: !0 });
		function se(e) {
			(e.key === "ArrowUp" || e.key === "ArrowDown") && (e.preventDefault(), e.stopPropagation(), U(e.key === "ArrowUp" ? 1 : -1));
		}
		function ce(e) {
			if (e.ctrlKey || (e.stopPropagation(), _.value && e.target.closest(".ui-toast__message")) || (e.preventDefault(), u.items.length < 2)) return;
			let t = performance.now();
			if (t < V || !Number.isFinite(e.deltaY)) return;
			(t - B > 200 || Math.sign(z) !== Math.sign(e.deltaY)) && (z = 0), B = t;
			let n = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 200 : 1);
			z += n, Math.abs(z) < 32 || (U(z > 0 ? -1 : 1), z = 0, V = t + 260);
		}
		let G = ne(b, {
			threshold: 24,
			onSwipeStart(e) {
				L(), P = p.value, j = e.isPrimary && e.button === 0 && !e.target.closest("button, .ui-toast__message.is-expanded"), R = !1;
			},
			onSwipe() {
				if (!j || P !== p.value || !b.value) return;
				R = !0;
				let e = -G.distanceX.value;
				Math.abs(e) > Math.abs(G.distanceY.value) && (b.value.style.transform = `translateX(${e}px)`, b.value.style.opacity = String(Math.max(.3, 1 - Math.abs(e) / b.value.clientWidth)));
			},
			onSwipeEnd(e, t) {
				j && P === p.value && (j = !1, b.value && (b.value.style.removeProperty("transform"), b.value.style.removeProperty("opacity")), e.type !== "pointercancel" && (t === "left" || t === "right" ? Math.abs(G.distanceX.value) >= 56 && W() : (t === "up" || t === "down") && U(t === "up" ? -1 : 1)));
			}
		});
		return ee(b, "click", (e) => {
			R && (e.preventDefault(), e.stopImmediatePropagation());
		}, { capture: !0 }), ee(b, "pointercancel", () => {
			j = !1;
		}), (t, r) => (v(), i(T(Ge), {
			duration: _.value ? Infinity : e.duration,
			label: e.label,
			"disable-swipe": ""
		}, {
			default: N(() => [l(n, {
				mode: "out-in",
				appear: "",
				css: !1,
				onEnter: ie,
				onLeave: ae
			}, {
				default: N(() => [O.value ? (v(), i(T(Ke), {
					key: O.value.id,
					"as-child": "",
					open: !0,
					"onUpdate:open": r[0] ||= (e) => {
						e || W();
					}
				}, {
					default: N(() => [s("li", {
						ref_key: "card",
						ref: b,
						class: "ui-toast",
						"data-ui": "toast",
						"data-tone": O.value.tone,
						"data-expanded": _.value || void 0,
						onKeydown: se
					}, [
						s("div", Pt, [(v(), i(S(E[O.value.tone]), {
							size: 17,
							"aria-hidden": "true"
						}))]),
						s("div", Ft, [l(T(We), { "as-child": "" }, {
							default: N(() => [s("p", {
								ref_key: "message",
								ref: x,
								class: g(["ui-toast__message", { "is-expanded": _.value }])
							}, w(O.value.message), 3)]),
							_: 1
						}), C.value || _.value ? (v(), o("div", It, [s("button", {
							class: "ui-toast__expand",
							type: "button",
							"aria-expanded": _.value,
							onClick: oe
						}, [c(w(_.value ? e.collapseLabel : e.expandLabel) + " ", 1), _.value ? (v(), i(T(Ye), {
							key: 0,
							size: 12,
							"aria-hidden": "true"
						})) : (v(), i(T(K), {
							key: 1,
							size: 12,
							"aria-hidden": "true"
						}))], 8, Lt)])) : a("v-if", !0)]),
						s("div", Rt, [l(T(Ue), {
							class: "ui-toast__close",
							"aria-label": e.closeLabel
						}, {
							default: N(() => [l(T(ot), {
								size: 14,
								"aria-hidden": "true"
							})]),
							_: 1
						}, 8, ["aria-label"]), e.items.length > 1 ? (v(), o("span", zt, [l(T(Je), null, {
							default: N(() => [c(w(e.positionLabel(k.value, e.items.length)), 1)]),
							_: 1
						}), s("span", Bt, w(k.value) + "/" + w(e.items.length), 1)])) : a("v-if", !0)])
					], 40, Nt)]),
					_: 1
				})) : a("v-if", !0)]),
				_: 1
			}), l(T(qe), m(t.$attrs, {
				class: "ui-toast-stack",
				"data-ui": "toast-stack",
				"data-compact": T(f) || void 0,
				"data-count": Math.min(e.items.length, 3),
				label: e.label,
				onWheel: ce,
				onTouchmove: r[1] ||= F(() => {}, ["stop"]),
				onPointerdown: r[2] ||= F(() => {}, ["stop"]),
				onPointerup: r[3] ||= F(() => {}, ["stop"])
			}), null, 16, [
				"data-compact",
				"data-count",
				"label"
			])]),
			_: 1
		}, 8, ["duration", "label"]));
	}
}), Q = /* @__PURE__ */ u({
	__name: "UiTransition",
	props: {
		preset: { default: "panel" },
		appear: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let t = e, { play: r } = X(), a = /* @__PURE__ */ new WeakMap();
		function o(e = !1) {
			if (t.preset === "drop") {
				let t = {
					opacity: 1,
					clipPath: "inset(-16px)"
				};
				return e ? [t, {
					opacity: 0,
					clipPath: "inset(100% -16px -16px)"
				}] : [{
					opacity: 0,
					clipPath: "inset(-16px -16px 100%)"
				}, t];
			}
			let n = t.preset === "panel" ? [{
				opacity: 0,
				scale: ".98"
			}, {
				opacity: 1,
				scale: "1"
			}] : [{ opacity: 0 }, { opacity: 1 }];
			return e ? n.reverse() : n;
		}
		function s(e, n) {
			let i = e;
			if (i.inert = !1, a.has(i)) {
				let e = a.get(i);
				e === null ? i.removeAttribute("aria-hidden") : i.setAttribute("aria-hidden", e), a.delete(i);
			}
			t.preset === "none" ? n() : r(i, o(), t.preset === "context-menu" ? 90 : 200, n);
		}
		function c(e, n) {
			let i = e;
			i.inert = !0, a.has(i) || a.set(i, i.getAttribute("aria-hidden")), i.setAttribute("aria-hidden", "true"), t.preset === "none" ? n() : r(i, o(!0), t.preset === "context-menu" ? 60 : 140, n);
		}
		return (t, r) => (v(), i(n, {
			css: !1,
			appear: e.appear,
			onEnter: s,
			onLeave: c
		}, {
			default: N(() => [x(t.$slots, "default")]),
			_: 3
		}, 8, ["appear"]));
	}
}), Ht = {
	top: "[data-ui-resize-edges~=\"top\"]",
	right: "[data-ui-resize-edges~=\"right\"]",
	bottom: "[data-ui-resize-edges~=\"bottom\"]",
	left: "[data-ui-resize-edges~=\"left\"]"
}, Ut = e.object({
	x: e.number().finite(),
	y: e.number().finite(),
	width: e.number().positive().finite(),
	height: e.number().positive().finite()
}), Wt = e.partialRecord(At, Ut);
function Gt(e, t, n, i) {
	let { width: a, height: o } = B({ includeScrollbar: !1 }), s = r(() => Mt(a.value)), c = r(() => e.size !== "fullscreen" && !!(e.draggable || e.resizable)), l = C(), u = z(() => `nexus.ui.dialog.${e.persistenceKey ?? ""}`, {}, void 0, {
		deep: !1,
		writeDefaults: !1,
		serializer: {
			read: (e) => Wt.parse(JSON.parse(e)),
			write: JSON.stringify
		},
		onError: i
	});
	function d(e) {
		let t = Math.max(1, a.value - 32), n = Math.max(1, o.value - 32), r = Math.min(t, Math.max(Math.min(320, t), e.width)), i = Math.min(n, Math.max(Math.min(240, n), e.height));
		return {
			x: Math.max(16, Math.min(e.x, a.value - r - 16)),
			y: Math.max(16, Math.min(e.y, o.value - i - 16)),
			width: r,
			height: i
		};
	}
	function f() {
		e.persistenceKey && l.value && (u.value = {
			...u.value,
			[s.value]: { ...l.value }
		});
	}
	function p() {
		if (l.value) return d(l.value);
		let e = n.value?.getBoundingClientRect();
		if (e) return d({
			x: e.left,
			y: e.top,
			width: e.width,
			height: e.height
		});
	}
	function m(e, t, n = 0, r = 0) {
		let i = p();
		if (!i) return;
		let s = i.x + n, c = i.y + r;
		l.value = d({
			...i,
			x: s,
			y: c,
			width: Math.min(e, a.value - s - 16),
			height: Math.min(t, o.value - c - 16)
		});
	}
	function h(t, n) {
		if (!c.value || !e.resizable) return;
		let r = p();
		r && (m(r.width + t, r.height + n), f());
	}
	M([
		n,
		t,
		c,
		() => e.persistenceKey,
		() => e.size,
		() => e.draggable,
		() => e.resizable,
		s
	], ([t, n, r], i, a) => {
		let o;
		a(() => {
			o?.unset();
		}), l.value = void 0, t && n && r && (l.value = e.persistenceKey && u.value[s.value] || void 0, o = st(t).draggable({
			enabled: !!e.draggable,
			allowFrom: ".ui-dialog__header",
			ignoreFrom: "button, a, input, textarea, select, [contenteditable], [data-dialog-no-drag]",
			listeners: {
				move: (e) => {
					let t = p();
					t && (l.value = d({
						...t,
						x: t.x + e.dx,
						y: t.y + e.dy
					}));
				},
				end: f
			}
		}).resizable({
			enabled: !!e.resizable,
			edges: Ht,
			modifiers: [st.modifiers.restrictSize({ min: {
				width: 320,
				height: 240
			} })],
			listeners: {
				move: (e) => m(e.rect.width, e.rect.height, e.deltaRect.left, e.deltaRect.top),
				end: f
			}
		}));
	}, {
		immediate: !0,
		flush: "post"
	});
	let g = r(() => l.value && d(l.value));
	return {
		enabled: c,
		style: r(() => g.value ? {
			left: `${g.value.x}px`,
			top: `${g.value.y}px`,
			width: `${g.value.width}px`,
			height: `${g.value.height}px`,
			maxHeight: `${Math.max(1, o.value - 32)}px`,
			transform: "none"
		} : void 0),
		resizeBy: h
	};
}
// src/ui/browser/components/UiScrollArea.vue
var $ = /* @__PURE__ */ u({
	__name: "UiScrollArea",
	props: {
		asChild: {
			type: Boolean,
			default: !1
		},
		gutter: { default: "auto" },
		overflow: { default: "auto" },
		scrollbar: { default: "auto" }
	},
	setup(e) {
		let t = e;
		return (e, n) => (v(), i(T(xe), {
			"as-child": t.asChild,
			class: "ui-scroll-area",
			"data-scrollbar-gutter": t.gutter,
			"data-scroll-overflow": t.overflow,
			"data-scrollbar": t.scrollbar
		}, {
			default: N(() => [x(e.$slots, "default")]),
			_: 3
		}, 8, [
			"as-child",
			"data-scrollbar-gutter",
			"data-scroll-overflow",
			"data-scrollbar"
		]));
	}
}), Kt = ["aria-label"], qt = {
	key: 0,
	class: "ui-resize-edges",
	"aria-hidden": "true"
}, Jt = ["data-ui-resize-edges"], Yt = /*#__PURE__*/ q(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiResizeHandle",
	props: {
		label: {},
		edges: { type: Boolean }
	},
	emits: ["resize"],
	setup(e, { emit: n }) {
		let r = e, i = n;
		function c(e) {
			let t = {
				ArrowLeft: [-1, 0],
				ArrowRight: [1, 0],
				ArrowUp: [0, -1],
				ArrowDown: [0, 1]
			}[e.key];
			if (!t) return;
			e.preventDefault(), e.stopPropagation();
			let n = e.shiftKey ? 48 : 16;
			i("resize", t[0] * n, t[1] * n);
		}
		return (e, n) => (v(), o(t, null, [s("button", m(e.$attrs, {
			type: "button",
			"data-ui": "resize-handle",
			"data-ui-resize-edges": "bottom right",
			class: ["ui-resize-handle", { "has-edges": r.edges }],
			"aria-label": r.label,
			onKeydown: c
		}), null, 16, Kt), r.edges ? (v(), o("span", qt, [(v(), o(t, null, b([
			"top",
			"right",
			"bottom",
			"left",
			"top left",
			"top right",
			"bottom left"
		], (e) => s("span", {
			key: e,
			"data-ui-resize-edges": e
		}, null, 8, Jt)), 64))])) : a("v-if", !0)], 64));
	}
}), [["__scopeId", "data-v-e6ff7434"]]), Xt = [
	"data-size",
	"data-geometry",
	"data-draggable"
], Zt = { class: "ui-dialog__surface" }, Qt = ["data-ui-selection"], $t = { class: "ui-dialog__heading" }, en = { class: "ui-dialog__footer" }, tn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiDialog",
	props: /*@__PURE__*/ p({
		modal: {
			type: Boolean,
			default: !0
		},
		title: {},
		description: {},
		closeLabel: {},
		size: { default: "md" },
		showClose: {
			type: Boolean,
			default: !0
		},
		closeDisabled: {
			type: Boolean,
			default: !1
		},
		closeOnEscape: {
			type: Boolean,
			default: !0
		},
		closeOnInteractOutside: {
			type: Boolean,
			default: !0
		},
		draggable: { type: Boolean },
		resizable: {
			type: Boolean,
			default: !0
		},
		resizeLabel: {},
		persistenceKey: {},
		gutter: { default: "symmetric" },
		scrollbar: {}
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ p([
		"storageError",
		"closeAutoFocus",
		"escapeKeyDown"
	], ["update:open"]),
	setup(e, { emit: t }) {
		let n = D(e, "open");
		M(n, (e) => {
			e && Et();
		}, {
			immediate: !0,
			flush: "sync"
		});
		let o = e, u = d()?.appContext.config.globalProperties.$t, f = r(() => o.resizeLabel ?? (typeof u == "function" ? u("desktop.resize", { title: o.title }) : "Resize " + o.title)), p = t, h = C(), g = r(() => {
			let e = n.value && document.fullscreenElement;
			return e instanceof HTMLElement ? e : void 0;
		}), _ = Gt(o, n, h, (e) => p("storageError", e));
		function y() {
			b(!1);
		}
		function b(e) {
			(e || !o.closeDisabled) && (n.value = e);
		}
		function S(e) {
			o.closeDisabled || !o.closeOnEscape ? e.preventDefault() : p("escapeKeyDown", e);
		}
		return (e, t) => (v(), i(T(pe), {
			open: n.value,
			modal: o.modal,
			"onUpdate:open": b
		}, {
			default: N(() => [l(T(fe), { to: g.value }, {
				default: N(() => [l(Q, { preset: "fade" }, {
					default: N(() => [o.modal && n.value ? (v(), i(T(de), {
						key: 0,
						"force-mount": "",
						"data-ui": "dialog-overlay",
						class: "ui-dialog-overlay"
					})) : a("v-if", !0)]),
					_: 1
				}), l(Q, null, {
					default: N(() => [n.value ? (v(), i(T(le), {
						key: 0,
						"force-mount": "",
						"as-child": "",
						onCloseAutoFocus: t[0] ||= (e) => p("closeAutoFocus", e),
						onEscapeKeyDown: S,
						onInteractOutside: t[1] ||= (e) => (o.closeDisabled || !o.closeOnInteractOutside) && e.preventDefault()
					}, {
						default: N(() => [s("div", m({
							ref_key: "element",
							ref: h
						}, {
							...e.$attrs,
							...!o.description && !("aria-describedby" in e.$attrs) ? { "aria-describedby": void 0 } : {}
						}, {
							"data-ui": "dialog",
							"data-size": o.size,
							"data-geometry": T(_).enabled.value || void 0,
							"data-draggable": T(_).enabled.value && o.draggable || void 0,
							style: T(_).style.value,
							class: "ui-dialog"
						}), [s("div", Zt, [
							l($, {
								"as-child": "",
								gutter: o.gutter,
								overflow: "hidden"
							}, {
								default: N(() => [s("header", {
									class: "ui-dialog__header",
									"data-ui-selection": o.draggable ? "none" : void 0
								}, [s("div", $t, [l(T(me), { class: "ui-dialog__title" }, {
									default: N(() => [x(e.$slots, "title", { title: o.title }, () => [c(w(o.title), 1)], !0)]),
									_: 3
								}), o.description ? (v(), i(T(ue), {
									key: 0,
									class: "ui-dialog__description"
								}, {
									default: N(() => [c(w(o.description), 1)]),
									_: 1
								})) : a("v-if", !0)]), o.showClose ? (v(), i(T(G), {
									key: 0,
									"as-child": ""
								}, {
									default: N(() => [l(J, {
										class: "ui-dialog__close",
										appearance: "ghost",
										"icon-only": "",
										disabled: o.closeDisabled,
										"aria-label": o.closeLabel
									}, {
										default: N(() => [l(T(ot), { size: 18 })]),
										_: 1
									}, 8, ["disabled", "aria-label"])]),
									_: 1
								})) : a("v-if", !0)], 8, Qt)]),
								_: 3
							}, 8, ["gutter"]),
							x(e.$slots, "body", { close: y }, () => [e.$slots.default ? (v(), i($, {
								key: 0,
								gutter: o.gutter,
								scrollbar: o.scrollbar,
								class: "ui-dialog__body"
							}, {
								default: N(() => [x(e.$slots, "default", { close: y }, void 0, !0)]),
								_: 3
							}, 8, ["gutter", "scrollbar"])) : a("v-if", !0)], !0),
							e.$slots.footer ? (v(), i($, {
								key: 0,
								"as-child": "",
								gutter: o.gutter,
								overflow: "hidden"
							}, {
								default: N(() => [s("footer", en, [x(e.$slots, "footer", { close: y }, void 0, !0)])]),
								_: 3
							}, 8, ["gutter"])) : a("v-if", !0)
						]), T(_).enabled.value && o.resizable ? (v(), i(Yt, {
							key: 0,
							edges: "",
							label: f.value,
							onResize: T(_).resizeBy
						}, null, 8, ["label", "onResize"])) : a("v-if", !0)], 16, Xt)]),
						_: 3
					})) : a("v-if", !0)]),
					_: 3
				})]),
				_: 3
			}, 8, ["to"])]),
			_: 3
		}, 8, ["open", "modal"]));
	}
}), [["__scopeId", "data-v-1e9f5ffc"]]);
// src/ui/browser/ui-selection.ts
function nn(e) {
	let t = e.ownerDocument.getSelection();
	return !!t && !t.isCollapsed && t.rangeCount > 0 && t.toString().length > 0 && t.getRangeAt(0).intersectsNode(e);
}
function rn(e) {
	if (e.button !== 0 || !e.isPrimary || e.shiftKey) return;
	let t = e.currentTarget;
	nn(t) && t.ownerDocument.getSelection()?.removeAllRanges();
}
function an(e) {
	e.detail !== 0 && nn(e.currentTarget) && (e.preventDefault(), e.stopImmediatePropagation());
}
var on = {
	beforeMount(e) {
		e.addEventListener("pointerdown", rn, !0), e.addEventListener("click", an, !0);
	},
	beforeUnmount(e) {
		e.removeEventListener("pointerdown", rn, !0), e.removeEventListener("click", an, !0);
	}
}, sn = [
	"disabled",
	"aria-label",
	"aria-describedby"
], cn = ["id"], ln = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiActionCard",
	props: {
		label: {},
		disabled: { type: Boolean }
	},
	setup(e) {
		let t = E();
		return (n, r) => (v(), o("button", {
			type: "button",
			class: "ui-action-card",
			disabled: e.disabled,
			"aria-label": e.label,
			"aria-describedby": T(t)
		}, [s("span", {
			id: T(t),
			class: "ui-action-card__content"
		}, [x(n.$slots, "default", {}, void 0, !0)], 8, cn)], 8, sn));
	}
}), [["__scopeId", "data-v-5969b36d"]]), un = /* @__PURE__ */ u({
	__name: "UiContextMenu",
	props: /*@__PURE__*/ p({
		items: {},
		disabled: { type: Boolean }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ p(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let r = D(e, "open"), c = n, u = y(), d = Dt(r), f = (e) => d.select(L(u), () => c("select", e));
		return (n, c) => (v(), o(t, null, [a(" 右键、键盘菜单键、触屏长按与焦点收尾均交给 Reka；组件只处理样式和选项。 "), l(T(oe), {
			open: r.value,
			"onUpdate:open": c[1] ||= (e) => r.value = e,
			modal: !1
		}, {
			default: N(() => [l(T(ce), {
				ref_key: "trigger",
				ref: u,
				"as-child": "",
				disabled: e.disabled
			}, {
				default: N(() => [x(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(T(W), null, {
				default: N(() => [l(Q, { preset: "context-menu" }, {
					default: N(() => [r.value ? (v(), i(T(ae), {
						key: 0,
						"force-mount": "",
						"data-ui": "context-menu",
						class: "ui-menu",
						onInteractOutside: T(d).interactOutside,
						onPointerupCapture: c[0] ||= (e) => e.button !== 0 && e.preventDefault(),
						onCloseAutoFocus: T(d).closeAutoFocus,
						"side-offset": 8,
						"collision-padding": 12
					}, {
						default: N(() => [(v(!0), o(t, null, b(e.items, (e) => (v(), o(t, { key: e.id }, [e.separatorBefore ? (v(), i(T(se), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(T(U), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => f(e.id)
						}, {
							default: N(() => [e.icon ? (v(), i(S(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, w(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, ["onInteractOutside", "onCloseAutoFocus"])) : a("v-if", !0)]),
					_: 1
				})]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"])], 2112));
	}
}), dn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiSwitch",
	props: /*@__PURE__*/ p({
		disabled: { type: Boolean },
		name: {},
		required: { type: Boolean }
	}, {
		modelValue: {
			type: Boolean,
			default: !1
		},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let t = D(e, "modelValue");
		return (n, r) => (v(), i(T(Le), {
			modelValue: t.value,
			"onUpdate:modelValue": r[0] ||= (e) => t.value = e,
			class: "ui-switch",
			"data-ui": "switch",
			disabled: e.disabled,
			name: e.name,
			required: e.required
		}, {
			default: N(() => [l(T(Re), { class: "ui-switch__thumb" })]),
			_: 1
		}, 8, [
			"modelValue",
			"disabled",
			"name",
			"required"
		]));
	}
}), [["__scopeId", "data-v-91553e58"]]), fn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "UiSlider",
	props: {
		modelValue: {},
		min: { default: 0 },
		max: { default: 100 },
		step: { default: 1 },
		disabled: { type: Boolean },
		name: {}
	},
	emits: [
		"update:modelValue",
		"commit",
		"cancel"
	],
	setup(e, { emit: t }) {
		let n = t;
		return (t, r) => (v(), i(T(Pe), {
			class: "ui-slider",
			"data-ui": "slider",
			"model-value": [e.modelValue],
			min: e.min,
			max: e.max,
			step: e.step,
			disabled: e.disabled,
			name: e.name,
			"onUpdate:modelValue": r[0] ||= (e) => e?.[0] !== void 0 && n("update:modelValue", e[0]),
			onValueCommit: r[1] ||= (e) => e[0] !== void 0 && n("commit", e[0]),
			onPointercancel: r[2] ||= (e) => n("cancel")
		}, {
			default: N(() => [l(T(Ie), { class: "ui-slider__track" }, {
				default: N(() => [l(T(Ne), { class: "ui-slider__range" })]),
				_: 1
			}), l(T(Fe), m(t.$attrs, { class: "ui-slider__thumb" }), null, 16)]),
			_: 1
		}, 8, [
			"model-value",
			"min",
			"max",
			"step",
			"disabled",
			"name"
		]));
	}
}), [["__scopeId", "data-v-589610c4"]]), pn = ["data-stable"], mn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiTabs",
	props: /*@__PURE__*/ p({
		options: {},
		label: {},
		defaultValue: {},
		stableHeight: { type: Boolean }
	}, {
		modelValue: {},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let n = D(e, "modelValue");
		return (r, u) => (v(), i(T(Ve), {
			modelValue: n.value,
			"onUpdate:modelValue": u[0] ||= (e) => n.value = e,
			"default-value": e.defaultValue,
			class: "ui-tabs",
			"data-ui": "tabs"
		}, {
			default: N(() => [l(T(Be), {
				class: "ui-tabs__list",
				"aria-label": e.label
			}, {
				default: N(() => [(v(!0), o(t, null, b(e.options, (e) => (v(), i(T(He), {
					key: e.value,
					value: e.value,
					disabled: e.disabled,
					class: "ui-tabs__trigger"
				}, {
					default: N(() => [e.icon ? (v(), i(S(e.icon), {
						key: 0,
						size: 16
					})) : a("v-if", !0), c(w(e.label), 1)]),
					_: 2
				}, 1032, ["value", "disabled"]))), 128))]),
				_: 1
			}, 8, ["aria-label"]), s("div", {
				class: "ui-tabs__panels",
				"data-stable": e.stableHeight || void 0
			}, [(v(!0), o(t, null, b(e.options, (t) => (v(), i(T(ze), {
				key: t.value,
				value: t.value,
				"force-mount": e.stableHeight,
				class: "ui-tabs__panel"
			}, {
				default: N(() => [x(r.$slots, t.value, {}, void 0, !0)]),
				_: 2
			}, 1032, ["value", "force-mount"]))), 128))], 8, pn)]),
			_: 3
		}, 8, ["modelValue", "default-value"]));
	}
}), [["__scopeId", "data-v-377c1fa0"]]), hn = ["data-tone"], gn = {
	key: 0,
	class: "ui-badge__dot",
	"aria-hidden": "true"
}, _n = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiBadge",
	props: {
		tone: { default: "neutral" },
		dot: {
			type: Boolean,
			default: !1
		}
	},
	setup(e) {
		return (t, n) => (v(), o("span", {
			class: "ui-badge",
			"data-ui": "badge",
			"data-tone": e.tone
		}, [e.dot ? (v(), o("span", gn)) : a("v-if", !0), x(t.$slots, "default", {}, void 0, !0)], 8, hn));
	}
}), [["__scopeId", "data-v-94a33925"]]), vn = {
	class: "ui-empty-state",
	"data-ui": "empty-state"
}, yn = {
	key: 0,
	class: "ui-empty-state__icon",
	"aria-hidden": "true"
}, bn = { key: 1 }, xn = {
	key: 2,
	class: "ui-empty-state__actions"
}, Sn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiEmptyState",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (v(), o("div", vn, [
			e.icon || t.$slots.icon ? (v(), o("span", yn, [x(t.$slots, "icon", {}, () => [(v(), i(S(e.icon), { size: 26 }))], !0)])) : a("v-if", !0),
			s("h3", null, w(e.title), 1),
			e.description ? (v(), o("p", bn, w(e.description), 1)) : a("v-if", !0),
			t.$slots.default ? (v(), o("div", xn, [x(t.$slots, "default", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-f7ed903a"]]), Cn = ["data-tone"], wn = ["disabled", "aria-label"], Tn = {
	key: 0,
	class: "ui-card__icon"
}, En = {
	class: "ui-card__body",
	"data-ui-selection": "text"
}, Dn = {
	key: 0,
	class: "ui-card__title-line"
}, On = ["title"], kn = { class: "ui-card__title-end" }, An = ["title"], jn = ["title"], Mn = {
	key: 3,
	class: "ui-card__tags"
}, Nn = {
	key: 0,
	class: "ui-card__side"
}, Pn = {
	key: 0,
	class: "ui-card__badge"
}, Fn = {
	key: 1,
	class: "ui-card__actions"
}, In = {
	key: 1,
	class: "ui-card__footer"
}, Ln = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiCard",
	props: {
		title: {},
		actionLabel: {},
		description: {},
		icon: {},
		tone: { default: "primary" },
		disabled: { type: Boolean }
	},
	emits: ["select"],
	setup(e) {
		return (t, n) => (v(), o("article", {
			class: "ui-card",
			"data-ui": "card",
			"data-tone": e.tone
		}, [
			P((v(), o("button", {
				type: "button",
				class: "ui-card__main",
				disabled: e.disabled,
				"aria-label": e.actionLabel,
				onClick: n[0] ||= (e) => t.$emit("select")
			}, [e.icon || t.$slots.icon ? (v(), o("span", Tn, [x(t.$slots, "icon", {}, () => [(v(), i(S(e.icon), { size: 23 }))], !0)])) : a("v-if", !0), s("span", En, [
				t.$slots["title-end"] ? (v(), o("span", Dn, [s("strong", { title: e.title }, w(e.title), 9, On), s("span", kn, [x(t.$slots, "title-end", {}, void 0, !0)])])) : (v(), o("strong", {
					key: 1,
					title: e.title
				}, w(e.title), 9, An)),
				e.description ? (v(), o("span", {
					key: 2,
					class: "ui-card__description",
					title: e.description
				}, w(e.description), 9, jn)) : a("v-if", !0),
				t.$slots.tags ? (v(), o("span", Mn, [x(t.$slots, "tags", {}, void 0, !0)])) : a("v-if", !0)
			])], 8, wn)), [[T(on)]]),
			t.$slots.aside || t.$slots.badge || t.$slots.actions ? (v(), o("div", Nn, [x(t.$slots, "aside", {}, () => [t.$slots.badge ? (v(), o("div", Pn, [x(t.$slots, "badge", {}, void 0, !0)])) : a("v-if", !0), t.$slots.actions ? (v(), o("div", Fn, [x(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)], !0)])) : a("v-if", !0),
			t.$slots.footer ? (v(), o("div", In, [x(t.$slots, "footer", {}, void 0, !0)])) : a("v-if", !0)
		], 8, Cn));
	}
}), [["__scopeId", "data-v-4238ec73"]]), Rn = /* @__PURE__ */ u({
	__name: "UiDropdownMenu",
	props: /*@__PURE__*/ p({
		items: {},
		disabled: { type: Boolean },
		align: { default: "end" },
		transition: { default: "none" }
	}, {
		open: {
			type: Boolean,
			default: !1
		},
		openModifiers: {}
	}),
	emits: /*@__PURE__*/ p(["select"], ["update:open"]),
	setup(e, { emit: n }) {
		let c = e, u = n, d = D(e, "open"), f = y(), p = r(() => !!c.disabled || !c.items.length), m = Dt(d, p), h = (e) => m.select(L(f), () => u("select", e));
		return (n, r) => (v(), i(T(ve), {
			open: d.value,
			"onUpdate:open": r[0] ||= (e) => d.value = e,
			modal: !1
		}, {
			default: N(() => [l(T(be), {
				ref_key: "trigger",
				ref: f,
				"as-child": "",
				disabled: p.value
			}, {
				default: N(() => [x(n.$slots, "default")]),
				_: 3
			}, 8, ["disabled"]), l(T(_e), null, {
				default: N(() => [l(Q, { preset: e.transition === "fade" ? "fade" : "none" }, {
					default: N(() => [d.value ? (v(), i(T(he), {
						key: 0,
						"force-mount": "",
						"data-ui": "dropdown-menu",
						class: "ui-menu",
						align: e.align,
						"side-offset": 5,
						"collision-padding": 12,
						onInteractOutside: T(m).interactOutside,
						onCloseAutoFocus: T(m).closeAutoFocus
					}, {
						default: N(() => [(v(!0), o(t, null, b(e.items, (e) => (v(), o(t, { key: e.id }, [e.separatorBefore ? (v(), i(T(ye), {
							key: 0,
							class: "ui-menu__separator"
						})) : a("v-if", !0), l(T(ge), {
							class: "ui-menu__item",
							"data-tone": e.tone ?? "neutral",
							disabled: e.disabled,
							onSelect: (t) => h(e.id)
						}, {
							default: N(() => [e.icon ? (v(), i(S(e.icon), {
								key: 0,
								size: 16
							})) : a("v-if", !0), s("span", null, w(e.label), 1)]),
							_: 2
						}, 1032, [
							"data-tone",
							"disabled",
							"onSelect"
						])], 64))), 128))]),
						_: 1
					}, 8, [
						"align",
						"onInteractOutside",
						"onCloseAutoFocus"
					])) : a("v-if", !0)]),
					_: 1
				}, 8, ["preset"])]),
				_: 1
			})]),
			_: 3
		}, 8, ["open"]));
	}
}), zn = {}, Bn = {
	class: "ui-list",
	"data-ui": "list"
};
function Vn(e, t) {
	return v(), o("ul", Bn, [x(e.$slots, "default", {}, void 0, !0)]);
}
var Hn = /*#__PURE__*/ q(zn, [["render", Vn], ["__scopeId", "data-v-a19901d7"]]), Un = {
	class: "ui-list-item",
	"data-ui": "list-item"
}, Wn = {
	key: 0,
	class: "ui-list-item__icon"
}, Gn = {
	class: "ui-list-item__body",
	"data-ui-selection": "text"
}, Kn = { class: "ui-list-item__heading" }, qn = ["title"], Jn = ["title"], Yn = {
	key: 1,
	class: "ui-list-item__actions"
}, Xn = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiListItem",
	props: {
		title: {},
		description: {},
		icon: {}
	},
	setup(e) {
		return (t, n) => (v(), o("li", Un, [
			e.icon || t.$slots.icon ? (v(), o("span", Wn, [x(t.$slots, "icon", {}, () => [(v(), i(S(e.icon), { size: 20 }))], !0)])) : a("v-if", !0),
			s("div", Gn, [s("div", Kn, [s("strong", { title: e.title }, w(e.title), 9, qn), x(t.$slots, "badge", {}, void 0, !0)]), e.description || t.$slots.description ? (v(), o("div", {
				key: 0,
				class: "ui-list-item__description",
				title: e.description
			}, [x(t.$slots, "description", {}, () => [c(w(e.description), 1)], !0)], 8, Jn)) : a("v-if", !0)]),
			t.$slots.actions ? (v(), o("div", Yn, [x(t.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)
		]));
	}
}), [["__scopeId", "data-v-cf274d89"]]), Zn = {
	key: 0,
	class: "ui-section__header"
}, Qn = { class: "ui-section__heading" }, $n = { key: 0 }, er = { key: 1 }, tr = {
	key: 0,
	class: "ui-section__actions"
}, nr = ["id"], rr = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiSection",
	props: /*@__PURE__*/ p({
		title: {},
		description: {},
		icon: {},
		appearance: { default: "plain" },
		collapsible: {
			type: Boolean,
			default: !1
		}
	}, {
		open: {
			type: Boolean,
			default: !0
		},
		openModifiers: {}
	}),
	emits: ["update:open"],
	setup(e) {
		let t = D(e, "open"), n = E();
		return (r, u) => (v(), i(T(H), {
			as: "section",
			class: "ui-section",
			"data-ui": "section",
			"data-appearance": e.appearance,
			open: !e.collapsible || t.value,
			"onUpdate:open": u[0] ||= (e) => t.value = e
		}, {
			default: N(() => [
				e.title || e.description || r.$slots.actions || e.collapsible ? (v(), o("header", Zn, [s("div", Qn, [e.title ? (v(), o("h2", $n, [e.icon ? (v(), i(S(e.icon), {
					key: 0,
					size: 18,
					"aria-hidden": "true"
				})) : a("v-if", !0), c(w(e.title), 1)])) : a("v-if", !0), e.description ? (v(), o("p", er, w(e.description), 1)) : a("v-if", !0)]), r.$slots.actions || e.collapsible ? (v(), o("div", tr, [x(r.$slots, "actions", {}, void 0, !0), e.collapsible ? (v(), i(T(ie), {
					key: 0,
					"as-child": ""
				}, {
					default: N(() => [l(J, {
						appearance: "ghost",
						density: "compact",
						"icon-only": "",
						"aria-label": e.title,
						"aria-controls": T(n)
					}, {
						default: N(() => [l(T(K), {
							class: "ui-section__chevron",
							size: 16,
							"aria-hidden": "true"
						})]),
						_: 1
					}, 8, ["aria-label", "aria-controls"])]),
					_: 1
				})) : a("v-if", !0)])) : a("v-if", !0)])) : a("v-if", !0),
				a(" 保持表单与列表挂载；折叠仅隐藏内容，不重置输入或业务状态。 "),
				e.collapsible ? (v(), i(T(V), {
					key: 1,
					"as-child": "",
					"force-mount": ""
				}, {
					default: N(() => [P(s("div", {
						id: T(n),
						class: "ui-section__content"
					}, [x(r.$slots, "default", {}, void 0, !0)], 8, nr), [[j, t.value]])]),
					_: 3
				})) : x(r.$slots, "default", {}, void 0, !0, 2)
			]),
			_: 3
		}, 8, ["data-appearance", "open"]));
	}
}), [["__scopeId", "data-v-30743471"]]), ir = {
	class: "ui-form-row",
	"data-ui": "form-row"
}, ar = { class: "ui-form-row__body" }, or = ["for"], sr = ["id"], cr = { class: "ui-form-row__control" }, lr = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiFormRow",
	props: {
		label: {},
		description: {},
		icon: {},
		id: {}
	},
	setup(e) {
		let t = e, n = E();
		return (r, l) => (v(), o("div", ir, [s("div", ar, [s("label", { for: t.id ?? T(n) }, [e.icon ? (v(), i(S(e.icon), {
			key: 0,
			size: 18,
			"aria-hidden": "true"
		})) : a("v-if", !0), c(w(e.label), 1)], 8, or), e.description ? (v(), o("p", {
			key: 0,
			id: `${t.id ?? T(n)}-description`
		}, w(e.description), 9, sr)) : a("v-if", !0)]), s("div", cr, [x(r.$slots, "default", {
			id: t.id ?? T(n),
			describedby: e.description ? `${t.id ?? T(n)}-description` : void 0
		}, void 0, !0)])]));
	}
}), [["__scopeId", "data-v-09c39235"]]), ur = {}, dr = {
	class: "ui-toolbar",
	"data-ui": "toolbar"
}, fr = { class: "ui-toolbar__content" }, pr = {
	key: 0,
	class: "ui-toolbar__actions"
};
function mr(e, t) {
	return v(), o("div", dr, [s("div", fr, [x(e.$slots, "default", {}, void 0, !0)]), e.$slots.actions ? (v(), o("div", pr, [x(e.$slots, "actions", {}, void 0, !0)])) : a("v-if", !0)]);
}
var hr = /*#__PURE__*/ q(ur, [["render", mr], ["__scopeId", "data-v-fe93da01"]]), gr = ["value", "aria-label"], _r = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiProgress",
	props: {
		label: {},
		value: {}
	},
	setup(e) {
		return (t, n) => (v(), o("progress", {
			class: "ui-progress",
			"data-ui": "progress",
			value: e.value,
			max: "100",
			"aria-label": e.label
		}, null, 8, gr));
	}
}), [["__scopeId", "data-v-13af356b"]]), vr = ["data-state", "data-density"], yr = { class: "ui-progress-row__heading" }, br = ["title"], xr = ["aria-label"], Sr = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiProgressRow",
	props: {
		density: { default: "default" },
		showProgress: {
			type: Boolean,
			default: !0
		},
		statusDisplay: { default: "percent" },
		label: {},
		state: {},
		statusLabel: {},
		value: {}
	},
	setup(e) {
		let n = e, l = {
			pending: Xe,
			running: nt,
			succeeded: Qe,
			failed: $e
		}, u = r(() => n.state === "succeeded" ? 100 : n.value === void 0 ? void 0 : Math.min(100, Math.max(0, n.value)));
		return (n, r) => (v(), o("div", {
			class: "ui-progress-row",
			"data-ui": "progress-row",
			"data-state": e.state,
			"data-density": e.density
		}, [
			s("div", yr, [
				(v(), i(S(l[e.state]), {
					size: e.density === "compact" ? 15 : 18,
					class: "ui-progress-row__icon",
					"aria-hidden": "true"
				}, null, 8, ["size"])),
				s("span", {
					class: "ui-progress-row__label",
					title: e.label
				}, w(e.label), 9, br),
				s("span", {
					class: "ui-progress-row__status",
					"aria-label": e.statusLabel
				}, [e.statusDisplay === "percent" && u.value !== void 0 ? (v(), o(t, { key: 0 }, [c(w(u.value) + "%", 1)], 64)) : (v(), o(t, { key: 1 }, [c(w(e.statusLabel), 1)], 64))], 8, xr)
			]),
			e.showProgress ? (v(), i(_r, {
				key: 0,
				label: e.label,
				value: u.value
			}, null, 8, ["label", "value"])) : a("v-if", !0),
			x(n.$slots, "default", {}, void 0, !0)
		], 8, vr));
	}
}), [["__scopeId", "data-v-840f5068"]]), Cr = { class: "ui-loading" }, wr = {
	key: 0,
	class: "ui-loading__caption",
	role: "status"
}, Tr = /*#__PURE__*/ q(/* @__PURE__ */ u({
	__name: "UiLoadingTiles",
	props: {
		label: {},
		icons: { default: () => [
			rt,
			at,
			et,
			it
		] },
		active: {
			type: Boolean,
			default: !0
		}
	},
	setup(e) {
		let n = k("tiles"), { play: r, enabled: c } = X(), l = {
			opacity: .65,
			transform: "translateY(0)"
		}, u = {
			opacity: 1,
			transform: "translateY(-5px)"
		};
		return M([
			n,
			c,
			() => e.active,
			() => e.icons
		], ([e, t, n], i, a) => {
			if (!e || !t || !n || !e.animate) return;
			let o = [...e.querySelectorAll(".ui-loading-tiles__tile")];
			if (!o.length) return;
			let s = o.map((e, t) => Array.from({ length: o.length * 2 + 1 }, (e, n) => n === t * 2 + 1 ? u : l)), c = !1, d, f = [];
			function p() {
				c || (f = o.map((e, t) => r(e, s[t], 2600, t ? void 0 : m)));
			}
			function m() {
				c || (d = requestAnimationFrame(p));
			}
			a(() => {
				c = !0, d !== void 0 && cancelAnimationFrame(d);
				for (let e of f) e();
			}), p();
		}, { flush: "post" }), (r, c) => (v(), o("div", Cr, [s("div", {
			ref_key: "tiles",
			ref: n,
			class: "ui-loading-tiles",
			"aria-hidden": "true"
		}, [(v(!0), o(t, null, b(e.icons, (e, t) => (v(), o("span", {
			key: t,
			class: "ui-loading-tiles__tile"
		}, [(v(), i(S(e), { "stroke-width": 1.5 }))]))), 128))], 512), x(r.$slots, "caption", {}, () => [e.label ? (v(), o("p", wr, w(e.label), 1)) : a("v-if", !0)], !0)]));
	}
}), [["__scopeId", "data-v-6e6f4bb8"]]), Er = e.enum([
	"UI_THEME_DUPLICATE",
	"UI_THEME_INVALID_TOKEN",
	"UI_THEME_NOT_INSTALLED",
	"UI_THEME_UNAVAILABLE"
]), Dr = Er.enum;
export { ln as UiActionCard, _n as UiBadge, J as UiButton, Ln as UiCard, un as UiContextMenu, tn as UiDialog, Rn as UiDropdownMenu, Sn as UiEmptyState, Dr as UiErrorCode, Er as UiErrorCodeSchema, vt as UiField, lr as UiFormRow, Ct as UiInput, Hn as UiList, Xn as UiListItem, Tr as UiLoadingTiles, _r as UiProgress, Sr as UiProgressRow, Yt as UiResizeHandle, $ as UiScrollArea, rr as UiSection, kt as UiSelect, fn as UiSlider, dn as UiSwitch, mn as UiTabs, Vt as UiToastStack, hr as UiToolbar, Q as UiTransition, Ht as uiResizeEdges, on as vSelectableAction };
