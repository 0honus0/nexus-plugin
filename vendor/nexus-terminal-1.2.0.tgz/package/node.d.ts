import { z } from 'zod';
import { MigrationProvider } from 'kysely/migration';
import { CookieOptions } from 'express';
import { IncomingHttpHeaders, OutgoingHttpHeaders } from 'node:http';
import { Readable } from 'node:stream';
import { Result } from 'neverthrow';
import { Kysely } from 'kysely';
import { WebSocket } from 'ws';

declare const LogLevelSchema: z.ZodEnum<{
    fatal: "fatal";
    error: "error";
    warn: "warn";
    info: "info";
    debug: "debug";
    trace: "trace";
}>;
type LogLevel = z.infer<typeof LogLevelSchema>;
/** 只接收有限的平面参数，不接收 Error、请求、配置或任意嵌套对象。 */
declare const LogParamsSchema: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>;
type LogParams = z.infer<typeof LogParamsSchema>;
/** 插件只描述事件；来源、插件身份、记录 ID 和时间由宿主生成。 */
declare const PluginLogInputSchema: z.ZodObject<{
    level: z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>;
    code: z.ZodString;
    params: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>>;
    correlationId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
type PluginLogInput = z.infer<typeof PluginLogInputSchema>;
/** ctx.app.log 仅提供本端记录，不提供通知、订阅、传输或历史读取。
 * 无效事件或卸载后的调用直接忽略，日志故障不影响插件业务，不返回失败结果。
 */
interface PluginLogApi {
    report(event: PluginLogInput): void;
}

/** 插件作用域的生命周期由运行时管理。 */
interface PluginScopeApi {
    readonly signal: AbortSignal;
    /** 登记当前作用域的资源清理。返回值用于撤销有效作用域中的登记。失效后登记会直接安排清理。 */
    onDispose(cleanup: () => void | Promise<void>): () => void;
}

/** 逻辑表名由宿主绑定插件身份。keys 应与表的主键顺序一致。 */
declare const BackupTableSchema: z.ZodObject<{
    table: z.ZodString;
    version: z.ZodInt;
    keys: z.ZodArray<z.ZodString>;
    fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodLiteral<"plain">, z.ZodLiteral<"secret">, z.ZodObject<{
        secret: z.ZodString;
    }, z.core.$strict>]>>;
}, z.core.$strict>;
type BackupTable = z.infer<typeof BackupTableSchema>;
type BackupDeclaration = readonly BackupTable[];

declare const PluginServiceReferenceSchema: z.ZodReadonly<z.ZodTuple<[z.ZodString, z.ZodString], null>>;
type PluginServiceReference = z.infer<typeof PluginServiceReferenceSchema>;
declare const PluginServiceSelectionSchema: z.ZodReadonly<z.ZodRecord<z.ZodString, z.ZodReadonly<z.ZodTuple<[z.ZodString, z.ZodString], null>>>>;
type PluginServiceSelection = z.infer<typeof PluginServiceSelectionSchema>;
type Provider<Services> = Extract<keyof Services, string>;
type ServiceName<Services, Owner extends Provider<Services>> = Extract<keyof Services[Owner], string>;
type DeclaredServiceReference<Services> = {
    [Owner in Provider<Services>]: {
        [Name in ServiceName<Services, Owner>]: readonly [Owner, Name];
    }[ServiceName<Services, Owner>];
}[Provider<Services>];
type ServiceRegistration<Services> = {
    [Owner in Provider<Services>]: {
        [Name in ServiceName<Services, Owner>]: [name: Name, service: Services[Owner][Name]];
    }[ServiceName<Services, Owner>];
}[Provider<Services>];
type SelectedServices<Services, Selection extends PluginServiceSelection> = {
    readonly [Alias in keyof Selection]: Selection[Alias] extends readonly [infer Owner, infer Name] ? Owner extends Provider<Services> ? Name extends ServiceName<Services, Owner> ? Services[Owner][Name] : never : never : never;
};

declare const PluginReadinessUpdateSchema: z.ZodDiscriminatedUnion<[z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"ready">;
}, z.core.$strict>>, z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"pending">;
    reason: z.ZodReadonly<z.ZodObject<{
        code: z.ZodLiteral<"PLUGIN_CONFIGURATION_REQUIRED">;
        applicationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>>], "state">;
type PluginReadinessUpdate = z.infer<typeof PluginReadinessUpdateSchema>;
declare const PluginReadinessSchema: z.ZodDiscriminatedUnion<[z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"ready">;
}, z.core.$strict>>, z.ZodReadonly<z.ZodObject<{
    state: z.ZodLiteral<"pending">;
    reason: z.ZodOptional<z.ZodReadonly<z.ZodObject<{
        code: z.ZodLiteral<"PLUGIN_CONFIGURATION_REQUIRED">;
        applicationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>>], "state">;
type PluginReadiness = z.infer<typeof PluginReadinessSchema>;

/** 已知 HTTP 失败。只有可公开的稳定标识和状态会进入响应。 */
declare class HttpFailure extends Error {
    readonly status: number;
    readonly code: string;
    constructor(status: number, code: string);
}

interface HttpRouteBase<Input extends z.ZodObject> {
    readonly method: 'get' | 'post' | 'put' | 'patch' | 'delete';
    /** 相对于登记方的路径，可使用 Express 命名参数；流路由允许末尾的命名通配段。 */
    readonly path: string;
    readonly input: Input;
    /** 缩短路由的生命周期，例如使用 ctx.use() 提供的依赖作用域。 */
    readonly lifetime?: PluginScopeApi;
}
interface HttpRoute<Input extends z.ZodObject, Output extends z.ZodObject, Context extends unknown[] = []> extends HttpRouteBase<Input> {
    readonly output: Output;
    /** 成功响应状态，省略时为 200。 */
    readonly status?: number;
    /** 请求断开或路由撤销时取消，处理函数应等待已发起的 I/O 完成。 */
    readonly handler: (input: z.output<NoInfer<Input>>, signal: AbortSignal, ...context: Context) => z.input<NoInfer<Output>> | Promise<z.input<NoInfer<Output>>>;
}
/** 内部容纳不同 Schema 的路由；各自的 handler 由公开登记签名校验。 */
type HttpJsonRouteRegistration<Context extends unknown[] = []> = Omit<HttpRoute<z.ZodObject, z.ZodObject, Context>, 'handler'> & {
    readonly handler: (input: never, signal: AbortSignal, ...context: Context) => z.input<z.ZodObject> | Promise<z.input<z.ZodObject>>;
};
interface HttpStreamResponse {
    readonly status?: number;
    readonly headers?: Readonly<Pick<OutgoingHttpHeaders, 'content-type' | 'cache-control' | 'content-security-policy' | 'content-length' | 'content-disposition' | 'content-range' | 'accept-ranges' | 'etag' | 'last-modified'>>;
    readonly body?: Readable;
}
interface HttpStreamContext {
    readonly method: string;
    readonly headers: Readonly<Pick<IncomingHttpHeaders, 'content-length' | 'content-type' | 'range' | 'if-match' | 'if-none-match' | 'if-range'>>;
    readonly signal: AbortSignal;
    readonly body: Readable | undefined;
    /** 等待传输完成；HEAD 仅发送响应头。 */
    reply(response: HttpStreamResponse): Promise<void>;
}
interface HttpStreamRoute<Input extends z.ZodObject> extends Omit<HttpRouteBase<Input>, 'method'> {
    readonly method: HttpRouteBase<Input>['method'] | 'head';
    readonly output?: never;
    /** 路径及查询交给 input 检查，二进制内容从 context.body 读取。 */
    readonly body?: 'binary';
    readonly handler: (input: z.output<NoInfer<Input>>, context: HttpStreamContext) => Promise<void>;
}
type HttpStreamRegistration = Omit<HttpStreamRoute<z.ZodObject>, 'handler'> & {
    readonly handler: (input: never, context: HttpStreamContext) => Promise<void>;
};
type HttpRouteRegistration<Context extends unknown[] = []> = HttpJsonRouteRegistration<Context> | HttpStreamRegistration;
type HttpRouteDefinition<Route extends HttpRouteRegistration> = Route extends HttpJsonRouteRegistration ? HttpRoute<Route['input'], Route['output']> : HttpStreamRoute<Route['input']>;
type HttpRouteBatch<Routes extends readonly HttpRouteRegistration[]> = Routes & {
    readonly [Index in keyof Routes]: HttpRouteDefinition<Routes[Index]>;
};
interface PluginHttpApi {
    /** 整批校验成功后登记到当前插件的路径，停用时自动撤销。 */
    register<const Routes extends readonly HttpRouteRegistration[]>(routes: HttpRouteBatch<Routes>): void;
}

declare const AuthAccountSchema: z.ZodObject<{
    id: z.ZodLiteral<"owner">;
    username: z.ZodString;
}, z.core.$strip>;
type AuthAccount = z.infer<typeof AuthAccountSchema>;

/** 当前登录请求可用的协议数据与响应能力。 */
interface AuthMethodContextApi {
    readonly url: URL;
    readonly cookieHeader: string | undefined;
    setCookie(name: string, value: string, options: CookieOptions): void;
    /** 设置 303 跳转，响应仍由宿主在处理函数结束后发送。 */
    redirect(location: string): void;
    /** 插件验证协议及身份绑定成功后，为当前请求建立本体账户会话。 */
    completeLogin(): Promise<void>;
}
interface AuthMethodRoute<Input extends z.ZodObject, Output extends z.ZodObject> extends Omit<HttpRoute<Input, Output, [context: AuthMethodContextApi]>, 'method' | 'lifetime'> {
    readonly method: 'get' | 'post';
    /** 允许 GET 接收第三方发起的顶层浏览器导航，例如 OIDC 回调。 */
    readonly callback?: true;
}
type AuthMethodRouteRegistration = Omit<HttpJsonRouteRegistration<[context: AuthMethodContextApi]>, 'method' | 'lifetime'> & Pick<AuthMethodRoute<z.ZodObject, z.ZodObject>, 'method' | 'callback'>;
interface AuthMethodRegistrationApi {
    readonly baseURL: string;
    /** 撤回本次登记，等待已进入的请求处理完毕。插件停用时也会自动执行。 */
    dispose(): Promise<void>;
}
interface AuthMethodApi {
    /** 读取本体账号的公开标识及用户名，不返回密码、凭据或会话。 */
    getAccount(signal: AbortSignal): Promise<AuthAccount | null>;
    /** id 在当前插件内唯一。label 是由登录页翻译的文案标识。 */
    register<const Routes extends readonly AuthMethodRouteRegistration[]>(method: {
        readonly id: string;
        readonly label: string;
        readonly routes: Routes & {
            readonly [Index in keyof Routes]: AuthMethodRoute<Routes[Index]['input'], Routes[Index]['output']>;
        };
    }): AuthMethodRegistrationApi;
}

declare const CryptoOptionsSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"local">;
    context: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"password">;
    password: z.ZodString;
    context: z.ZodOptional<z.ZodString>;
}, z.core.$strict>], "mode">;
type CryptoOptions = z.infer<typeof CryptoOptionsSchema>;
/** 只公开可处理的稳定标识，不包含内部 Error、cause、stack 或密钥状态。 */
declare const PluginCryptoErrorCodeSchema: z.ZodEnum<{
    INVALID_INPUT: "INVALID_INPUT";
    INVALID_OPTIONS: "INVALID_OPTIONS";
    INVALID_ENVELOPE: "INVALID_ENVELOPE";
    AUTHENTICATION_FAILED: "AUTHENTICATION_FAILED";
    UNAVAILABLE: "UNAVAILABLE";
    CANCELLED: "CANCELLED";
    INTERNAL_ERROR: "INTERNAL_ERROR";
}>;
type PluginCryptoErrorCode = z.infer<typeof PluginCryptoErrorCodeSchema>;
declare const PluginCryptoFailureSchema: z.ZodObject<{
    code: z.ZodEnum<{
        INVALID_INPUT: "INVALID_INPUT";
        INVALID_OPTIONS: "INVALID_OPTIONS";
        INVALID_ENVELOPE: "INVALID_ENVELOPE";
        AUTHENTICATION_FAILED: "AUTHENTICATION_FAILED";
        UNAVAILABLE: "UNAVAILABLE";
        CANCELLED: "CANCELLED";
        INTERNAL_ERROR: "INTERNAL_ERROR";
    }>;
    correlationId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
type PluginCryptoFailure = z.infer<typeof PluginCryptoFailureSchema>;
/** ctx.app.crypto 契约，身份由宿主绑定。
 * 密码模式可跨实例解密，仍要求相同所有者、密码和 context。
 * 已知失败与未知异常均在宿主边界转成失败结果，由插件决定如何展示。
 * 插件取消后返回 CANCELLED，不交付运算结果，不代表已经终止底层运算。
 */
interface PluginCryptoApi {
    encrypt(plaintext: Uint8Array, options: CryptoOptions): Promise<Result<Uint8Array, PluginCryptoFailure>>;
    decrypt(envelope: Uint8Array, options: CryptoOptions): Promise<Result<Uint8Array, PluginCryptoFailure>>;
}

interface PluginDatabaseApi {
    /** 使用逻辑表名。在回调内完成查询、事务或流式读取，客户端随插件实例释放。 */
    withClient<Result>(operation: (client: Kysely<unknown>) => Result | Promise<Result>): Promise<Result>;
}

interface StateRegistration<Schema extends z.ZodType> {
    readonly name: string;
    readonly schema: Schema;
    readonly initial: z.input<NoInfer<Schema>>;
    readonly lifetime?: PluginScopeApi;
}
interface StatePublisherApi<Value> {
    /** 发布该主题的当前值，宿主计算传输增量。 */
    publish(value: Value): void;
}
interface PluginStateApi {
    /** 宿主绑定插件 ID，停用或依赖作用域关闭时自动撤销主题。 */
    register<Schema extends z.ZodType>(options: StateRegistration<Schema>): StatePublisherApi<z.input<Schema>>;
}

interface WsConnectionContext {
    readonly query: URLSearchParams;
    /** 连接关闭、会话失效或插件停用时取消。 */
    readonly signal: AbortSignal;
}
interface WsRoute {
    readonly path: string;
    readonly maxPayload?: number;
    readonly lifetime?: PluginScopeApi;
    /** 文本和二进制消息由业务协议处理，宿主负责握手和连接生命周期。 */
    handler(socket: WebSocket, context: WsConnectionContext): void | Promise<void>;
}
interface PluginWsApi {
    /** 在当前插件命名空间登记会话保护的路径。插件停用时自动撤销。 */
    register(route: WsRoute): void;
}

/** Node 宿主为插件实例装配的能力。 */
interface PluginAppApi {
    readonly crypto: PluginCryptoApi;
    readonly database: PluginDatabaseApi;
    readonly http: PluginHttpApi;
    readonly log: PluginLogApi;
    readonly state: PluginStateApi;
    readonly ws: PluginWsApi;
}
/** 插件通过 Node SDK 按包名和服务名扩充此接口。 */
interface PluginServicesApi {
}
interface PluginServiceScopeApi extends PluginScopeApi {
    provide(...registration: ServiceRegistration<PluginServicesApi>): () => void;
}
type PluginCleanup = () => void | Promise<void>;
/** 绑定随依赖失效而取消。回调可登记清理，恢复时宿主交付新的作用域。 */
interface PluginDependencyScopeApi<Services = Record<string, unknown>> extends PluginServiceScopeApi {
    readonly plugin: Readonly<Services>;
}
interface PluginReadinessApi {
    readonly value: PluginReadiness;
    set(update: PluginReadinessUpdate): void;
}
interface PluginSelfApi {
    readonly id: string;
    readonly readiness: PluginReadinessApi;
}
/** Node 插件运行时交给 activate 的上下文。 */
interface PluginContextApi extends PluginServiceScopeApi {
    readonly app: PluginAppApi;
    readonly self: PluginSelfApi;
    /** 由声明 nexus.authMethods 的后端插件用来登记登录方式。 */
    readonly authMethods?: AuthMethodApi;
    /** 登记依赖回调。宿主在服务可用后运行回调，activate 可先完成。 */
    use<const Selection extends Readonly<Record<string, DeclaredServiceReference<PluginServicesApi>>>>(services: Selection, setup: (scope: PluginDependencyScopeApi<SelectedServices<PluginServicesApi, Selection>>) => void | PluginCleanup | Promise<void | PluginCleanup>): () => void;
}
/** Node 插件入口的命名导出。 */
interface PluginModuleApi {
    /** 随迁移登记的可移植数据声明。 */
    readonly backup?: BackupDeclaration;
    /** 本体在激活之前执行的 SQL 迁移定义。 */
    readonly migrations?: MigrationProvider;
    /** 资源取得后可用 context.onDispose 登记，即使本次激活失败也会清理。 */
    activate(context: PluginContextApi): void | Promise<void>;
    /** 整个插件停用时调用。只对激活成功的实例执行，此时作用域信号已取消。 */
    deactivate?(context: PluginContextApi): void | Promise<void>;
}

export { CryptoOptionsSchema, HttpFailure, LogLevelSchema, LogParamsSchema, PluginCryptoErrorCodeSchema, PluginCryptoFailureSchema, PluginLogInputSchema };
export type { AuthAccount, AuthMethodApi, AuthMethodContextApi, AuthMethodRegistrationApi, AuthMethodRoute, BackupDeclaration, BackupTable, CryptoOptions, HttpRoute, HttpStreamContext, HttpStreamResponse, HttpStreamRoute, LogLevel, LogParams, PluginAppApi, PluginContextApi, PluginCryptoApi, PluginCryptoErrorCode, PluginCryptoFailure, PluginDatabaseApi, PluginDependencyScopeApi, PluginHttpApi, PluginLogApi, PluginLogInput, PluginModuleApi, PluginReadiness, PluginReadinessApi, PluginReadinessUpdate, PluginScopeApi, PluginSelfApi, PluginServiceReference, PluginServiceSelection, PluginServicesApi, PluginStateApi, PluginWsApi, StatePublisherApi, StateRegistration, WsConnectionContext, WsRoute };
